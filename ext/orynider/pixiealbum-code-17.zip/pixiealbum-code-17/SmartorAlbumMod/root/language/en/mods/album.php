<?php
/** 
*
* album  [English]
*
* @package language
* @version $Id: album.php,v 1.1.0 2009/03/04 13:51:00 nuffmon Exp $
* @copyright (c) 2005 phpBB Group 
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* DO NOT CHANGE
*/
if (empty($lang) || !is_array($lang))
{
  $lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

// Config
$lang = array_merge($lang, array(  
  'Album_config' => 'Album Configuration',
  'Album_config_explain' => 'You can change the general settings of your Photo Album here',
  'Album_config_updated' => 'Album Configuration has been updated successfully',
  'Click_return_album_config' => 'Click %sHere%s to return to the Album Configuration',
  'Max_pics' => 'Maximum pics for each Category (-1 => unlimited)',
  'User_pics_limit' => 'Pics limit per category for each user (-1 => unlimited)',
  'Moderator_pics_limit' => 'Pics limit per category for each moderator (-1 => unlimited)',
  'Pics_Approval' => 'Pics Approval',
  'Rows_per_page' => 'Number of rows on thumbnail page',
  'Cols_per_page' => 'Number of columns on thumbnail page',
  'Thumbnail_quality' => 'Thumbnail quality (1-100)',
  'Thumbnail_cache' => 'Thumbnail cache',
  'Manual_thumbnail' => 'Manual thumbnail',
  'GD_version' => 'Optimize for the version of GD',
  'Pic_Desc_Max_Length' => 'Pic Description/Comment Max Length (bytes)',
  'Hotlink_prevent' => 'Hotlink Prevention',
  'Hotlink_allowed' => 'Allowed domains for hotlink (separated by a comma)',
  'Personal_gallery' => 'Allowed to create personal gallery for users',
  'Personal_gallery_limit' => 'Pics limit for each personal gallery (-1 => unlimited)',
  'Personal_gallery_view' => 'Who can view personal galleries',
  'Rate_system' => 'Enable rate system',
  'Rate_Scale' =>' Rating Scale',
  'Comment_system' => 'Enable comment system',
  'Thumbnail_Settings' => 'Thumbnail Settings',
  'Extra_Settings' => 'Extra Settings',
  'Default_Sort_Method' => 'Default Sort Method',
  'Default_Sort_Order' => 'Default Sort Order',
  'Fullpic_Popup' => 'View full pic as a popup',
));


// Personal Gallery Page
$lang = array_merge($lang, array(
  'Personal_Galleries' => 'Personal Galleries',
  'Album_personal_gallery_title' => 'Personal Gallery',
  'Album_personal_gallery_explain' => 'On this page, you can choose which usergroups have right to create and view personal galleries. These settings only affect when you set "PRIVATE" for "Allowed to create personal gallery for users" or "Who can view personal galleries" in Album Configuration screen',
  'Album_personal_successfully' => 'The setting has been updated successfully',
  'Click_return_album_personal' => 'Click %sHere%s to return to the Personal Gallery Settings',
));

// Categories
$lang = array_merge($lang, array(
  'Category' => 'Category',
  'Album_Categories_Title' => 'Album Categories Control',
  'Album_Categories_Explain' => 'On this screen you can manage your categories: create, alter, delete, sort, etc.',
  'Category_Permissions' => 'Category Permissions',
  'Category_Title' => 'Category Title',
  'Category_Desc' => 'Category Description',
  'View_level' => 'View Level',
  'Upload_level' => 'Upload Level',
  'Rate_level' => 'Rate Level',
  'Comment_level' => 'Comment Level',
  'Edit_level' => ' Edit Level',
  'Delete_level' => 'Delete Level',
  'New_category_created' => 'New category has been created successfully',
  'Click_return_album_category' => 'Click %sHere%s to return to the Album Categories Manager',
  'Category_updated' => 'This category has been updated successfully',
  'Delete_Category' => 'Delete Category',
  'Delete_Category_Explain' => 'The form below will allow you to delete a category and decide where you want to put pics it contained',
  'Delete_all_pics' => 'Delete all pics',
  'Category_deleted' => 'This category has been deleted successfully',
  'Category_changed_order' => 'This category has been changed order successfully',
  'Create_category' => 'Create Category',
  'Edit_category' => 'Edit Category',
  'Move_up' => 'Move Up',
  'Move_down' => 'Move Down',
  'Edit' => 'Edit',
  'Delete' => 'Delete',
  'Move_contents' => 'Move Contents',
  'Move_and_delete' => 'Move and Delete',
));

// Permissions
$lang = array_merge($lang, array(
  'Album_auth_title' => 'Album Permissions',
  'Album_auth_explain' => 'Here you can choose which usergroup(s) can be the moderators for each album category or just has the private access',
  'Select_a_Category' => 'Select a Category',
  'Look_up_Category' => 'Look up Category',
  'First_Create_Category' => 'You must create at least one category before setting permissions.',
  'Album_Auth_successfully' => 'Auth has been updated successfully',
  'Click_return_album_auth' => 'Click %sHere%s to return to the Album Permissions',
  'Upload' => 'Upload',
  'Rate' => 'Rate',
  'Comment' => 'Comment',
  'Is_moderator' => 'Is Moderator',
));

// Clear Cache
$lang = array_merge($lang, array(
  'Clear_Cache' => 'Clear Cache',
  'Album_clear_cache_confirm' => 'If you use the Thumbnail Cache feature you must clear your thumbnail cache after changing your thumbnail settings in Album Configuration to make them re-generated.<br /><br /> Do you want to clear them now?',
  'Thumbnail_cache_cleared_successfully' => '<br />Your thumbnail cache has been cleared successfully',
));

// Album Index
$lang = array_merge($lang, array(
  'Photo_Album' => 'Photo Album',
  'Pics' => 'Pics',
  'Last_Pic' => 'Last Pic',
  'Public_Categories' => 'Public Categories',
  'No_Pics' => 'No Pics',
  'Users_Personal_Galleries' => 'Users Personal Galleries',
  'Your_Personal_Gallery' => 'Your Personal Gallery',
  'Recent_Public_Pics' => 'Recent Public Pics',
  'View' => 'View',
));

// Category View
$lang = array_merge($lang, array(
  'Category_not_exist' => 'This category does not exist',
  'Upload_Pic' => 'Upload Pic',
  'Pic_Title' => 'Pic Title',
  'Waiting' => ' pic(s) waiting for approval',
  'Album_upload_can' => 'You <b>can</b> upload new pics in this category',
  'Album_upload_cannot' => 'You <b>cannot</b> upload new pics in this category',
  'Album_rate_can' => 'You <b>can</b> rate pics in this category',
  'Album_rate_cannot' => 'You <b>cannot</b> rate pics in this category',
  'Album_comment_can' => 'You <b>can</b> post comments to pics in this category',
  'Album_comment_cannot' => 'You <b>cannot</b> post comments to pics in this category',
  'Album_view_can' => 'You <b>can</b> view pics in this category',
  'Album_view_cannot' => 'You <b>cannot</b> view pics in this category',
  'Album_edit_can' => 'You <b>can</b> edit your pics and comments in this category',
  'Album_edit_cannot' => 'You <b>cannot</b> edit your pics and comments in this category',
  'Album_delete_can' => 'You <b>can</b> delete your pics and comments in this category',
  'Album_delete_cannot' => 'You <b>cannot</b> delete your pics and comments in this category',
  'Album_moderate_can' => 'You <b>can</b> %smoderate%s this category',
  'Edit_pic' => 'Edit',
  'Delete_pic' => 'Delete',
  'Rating' => 'Rating',
  'Comments' => 'Comments',
  'New_Comment' => 'New Comment',
  'Post_your_comment' => 'Post your comment', 
  'Not_rated' => '<i>not rated</i>',
));

// Upload
$lang = array_merge($lang, array(
  'Pic_Desc' => 'Pic Description',
  'Plain_text_only' => 'Plain text only',
  'Max_length' => 'Max length (bytes)',
  'Upload_pic_from_machine' => 'Upload a pic from your machine',
  'Upload_to_Category' => 'Upload to Category',
  'Upload_thumbnail_from_machine' => 'Upload its thumbnail from your machine (must be the same type with your pic)',
  'Upload_thumbnail' => 'Upload a thumbnail image',
  'Upload_thumbnail_explain' => 'It must be of the same file type as your picture',
  'Thumbnail_size' => 'Thumbnail size (pixel)',
  'Filetype_and_thumbtype_do_not_match' => 'Your pic and your thumbnail must be the same type',
  'Upload_no_title' => 'You must enter a title for your pic',
  'Upload_no_file' => 'You must enter your path and your filename',
  'Desc_too_long' => 'Your description is too long',
  'Max_file_size' => 'Maximum file size (bytes)',
  'Max_width' => 'Maximum image width (pixel)',
  'Max_height' => 'Maximum image height (pixel)',
  'JPG_allowed' => 'Allowed to upload JPG files',
  'PNG_allowed' => 'Allowed to upload PNG files',
  'GIF_allowed' => 'Allowed to upload GIF files',
  'Album_reached_quota' => 'This category has reached the quota of pics. Now you cannot upload any more. Please contact the administrators for more information',
  'User_reached_pics_quota' => 'You have reached your quota of pics. Now you cannot upload any more. Please contact the administrators for more information',
  'Bad_upload_file_size' => 'Your uploaded file is too large or corrupted',
  'Not_allowed_file_type' => 'Your file type is not allowed',
  'Upload_image_size_too_big' => 'Your image dimension size is too large',
  'Upload_thumbnail_size_too_big' => 'Your thumbnail dimension size is too large',
  'Missed_pic_title' => 'You must enter your pic title',
  'Album_upload_successful' => 'Your pic has been uploaded successfully',
  'Album_upload_need_approval' => 'Your pic has been uploaded successfully.<br /><br />But the feature Pic Approval has been enabled so your pic must be approved by a administrator or a moderator before posting',
  'Click_return_category' => 'Click %shere%s to return to the category',
  'Click_return_album_index' => 'Click %shere%s to return to the Album Index',
));

// View Pic
$lang = array_merge($lang, array(
  'Pic_not_exist' => 'This pic does not exist',
));

// Edit Pic
$lang = array_merge($lang, array(
  'Edit_Pic_Info' => 'Edit Pic Information',
  'Pics_updated_successfully' => 'Your pic information has been updated successfully',
));

// Delete Pic
$lang = array_merge($lang, array(
  'Album_delete_confirm' => 'Are you sure to delete these pic(s)?',
  'Pics_deleted_successfully' => 'These pic(s) have been deleted successfully',
));

// ModCP
$lang = array_merge($lang, array(
  'Approval' => 'Approval',
  'Approve' => 'Approve',
  'Unapprove' => 'Unapprove',
  'Status' => 'Status',
  'Locked' => 'Locked',
  'Lock' => 'Lock',
  'Unlock' => 'Unlock',
  'Not_approved' => 'Not approved',
  'Approved' => 'Approved',
  'Move_to_Category' => 'Move to Category',
  'Pics_moved_successfully' => 'Your pic(s) have been moved successfully',
  'Pics_locked_successfully' => 'Your pic(s) have been locked successfully',
  'Pics_unlocked_successfully' => 'Your pic(s) have been unlocked successfully',
  'Pics_approved_successfully' => 'Your pic(s) have been approved successfully',
  'Pics_unapproved_successfully' => 'Your pic(s) have been unapproved successfully',
));

// Rate
$lang = array_merge($lang, array(
  'Current_Rating' => 'Current Rating',
  'Please_Rate_It' => 'Please Rate It',
  'Already_rated' => 'You have already rated this pic',
  'Album_rate_successfully' => 'Your pic has been rated successfully',
));

// Comment
$lang = array_merge($lang, array(
  'Comment_no_text' => 'Please enter your comment',
  'Comment_too_long' => 'Your comment is too long',
  'Comment_delete_confirm' => 'Are you sure to delete this comment?',
  'Pic_Locked' => 'Sorry, this pic was locked. So you cannot post comment for this pic anymore',
  'Stored' => 'Your comment has been entered successfully',
  'Click_view_message' => 'Click %shere%s to view your message',
));

// Personal Gallery
$lang = array_merge($lang, array(
  'Personal_Gallery_Of_User' => 'Personal Gallery of ',
  'Personal_Gallery_Explain' => 'You can view the personal galleries of other members by clicking on the link in their profiles',
  'Personal_gallery_not_created' => 'The personal gallery of %s is empty or has not been created',
  'Not_allowed_to_create_personal_gallery' => 'Sorry, the administrators of this board donot allowed you to create your personal gallery',
  'Click_return_personal_gallery' => 'Click %shere%s to return to the personal gallery',
));

// Misc
$lang = array_merge($lang, array(
  'Time' => 'Time',
  'Sort_Username' => 'Username',
  'Sort_Ascending' => 'Asc',
  'Sort_Descending' => 'Desc',
  'Forum_ALL' => 'ALL',
  'Forum_PRIVATE' => 'PRIVATE',
  'Forum_REG' => 'REG',
  'Forum_MOD' => 'MOD',
  'Forum_ADMIN' => 'ADMIN',
  'Disabled' => 'Disabled',
  'Enabled' => 'Enabled',
  'Yes' => 'Yes',
  'No' => 'No',
  'None' => 'None',
  'Submit' => 'Submit',
  'Auth_Control_Group' => 'Group Permission Control',
  'Usergroups' => 'User Groups',
  'Private_access' => 'Private Access',
  'Reset' => 'Reset',
  'Go' => 'Go',
  'Jump_to' => 'Jump to',
  'Moderators' => 'Moderators',
  'Poster' => 'Poster',
  'Posted' => 'Posted',
  'Order' => 'Order',
  'Sort' => 'Sort',
  'Select_sort_method' => 'Select sort method',
));
?>
