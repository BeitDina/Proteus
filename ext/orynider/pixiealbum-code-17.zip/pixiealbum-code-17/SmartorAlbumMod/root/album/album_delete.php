<?php
/***************************************************************************
 *                              album_delete.php
 *                            -------------------
 *   begin                : Wednesday, February 05, 2003
 *   copyright            : (C) 2003 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_delete.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/album');

$album_root_path = $phpbb_root_path . 'album/';
include($album_root_path . 'album_constants.' . $phpEx);
include($album_root_path . 'album_common.'.$phpEx);

// Add album to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Photo_Album'],
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album.$phpEx"))
);

// ------------------------------------
// Check the request
// ------------------------------------

if( isset($_REQUEST['pic_id']) )
{
	$pic_id = request_var('pic_id', 0);
}
else
{
  trigger_error('No pics specified', E_USER_ERROR);
}


// ------------------------------------
// Get this pic info
// ------------------------------------

$sql = "SELECT *
        FROM ". ALBUM_TABLE ."
        WHERE pic_id = '$pic_id'";
$result = $db->sql_query($sql);

$thispic = $db->sql_fetchrow($result);

$cat_id = $thispic['pic_cat_id'];
$user_id = $thispic['pic_user_id'];

$pic_filename = $thispic['pic_filename'];
$pic_thumbnail = $thispic['pic_thumbnail'];

if( empty($thispic) )
{
    trigger_error($user->lang['Pic_not_exist'], E_USER_WARNING);
}


// ------------------------------------
// Get the current Category Info
// ------------------------------------

if ($cat_id != PERSONAL_GALLERY)
{
    $sql = "SELECT *
            FROM ". ALBUM_CAT_TABLE ."
            WHERE cat_id = '$cat_id'";
    $result = $db->sql_query($sql);

    $thiscat = $db->sql_fetchrow($result);
}
else
{
    $thiscat = init_personal_gallery_cat($user_id);
}

if (empty($thiscat))
{
    trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
}


// ------------------------------------
// Check the permissions
// ------------------------------------

$album_user_access = album_user_access($cat_id, $thiscat, 0, 0, 0, 0, 0, 1); // DELETE

if ($album_user_access['delete'] == 0)
{
    if (!$user->data['is_registered'])
    {
        redirect(append_sid("login.$phpEx?redirect=album_delete.$phpEx?pic_id=$pic_id"));
    }
    else
    {
        trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
    }
}
else
{
    if( (!$album_user_access['moderator']) and ($auth->acl_get('a_')) )
    {
        if ($thispic['pic_user_id'] != $user->data['user_id'])
        {
            trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
        }
    }
}



/*
+----------------------------------------------------------
| Main work here...
+----------------------------------------------------------
*/

if( !isset($_POST['confirm']) )
{
    // --------------------------------
    // If user give up deleting...
    // --------------------------------
    if( isset($_POST['cancel']) )
    {
        if ($cat_id) { 
        redirect(append_sid("album_cat.$phpEx?cat_id=$cat_id")); 
      } 
      else { 
        redirect(append_sid("album_personal.$phpEx?user_id=$user_id")); 
      } 
      exit;
    }

    //
    // Start output of page
    //
    
    $template->assign_vars(array(
        'MESSAGE_TITLE' => $user->lang['CONFIRM'],
        'MESSAGE_TEXT' => $user->lang['Album_delete_confirm'],
        'L_NO' => $user->lang['NO'],
        'YES_VALUE' => $user->lang['YES'],
        'S_CONFIRM_ACTION' => append_sid("album_delete.$phpEx?pic_id=$pic_id"),
        )
    );

    //
    // Generate the page
    //
    page_header($user->lang['Photo_Album']);

    $template->set_filenames(array(
        'body' => 'confirm_body.html')
    );

    page_footer();
}
else
{
    // --------------------------------
    // It's confirmed. First delete all comments
    // --------------------------------
    $sql = "DELETE FROM ". ALBUM_COMMENT_TABLE ."
            WHERE comment_pic_id = '$pic_id'";
    $result = $db->sql_query($sql);


    // --------------------------------
    // Delete all ratings
    // --------------------------------
    $sql = "DELETE FROM ". ALBUM_RATE_TABLE ."
            WHERE rate_pic_id = '$pic_id'";
    $result = $db->sql_query($sql);


    // --------------------------------
    // Delete cached thumbnail
    // --------------------------------
    if(($thispic['pic_thumbnail'] != '') and @file_exists(ALBUM_CACHE_PATH . $thispic['pic_thumbnail']))
    {
        @unlink(ALBUM_CACHE_PATH . $thispic['pic_thumbnail']);
    }


    // --------------------------------
    // Delete File
    // --------------------------------
    @unlink(ALBUM_UPLOAD_PATH . $thispic['pic_filename']);


    // --------------------------------
    // Delete DB entry
    // --------------------------------
    $sql = "DELETE FROM ". ALBUM_TABLE ."
            WHERE pic_id = '$pic_id'";
    $result = $db->sql_query($sql);


    // --------------------------------
    // Complete... now send a message to user
    // --------------------------------

    $message = $user->lang['Pics_deleted_successfully'];

    if ($cat_id != PERSONAL_GALLERY)
    {
        $template->assign_vars(array(
            'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("album_cat.$phpEx?cat_id=$cat_id") . '">')
        );

        $message .= "<br /><br />" . sprintf($user->lang['Click_return_category'], "<a href=\"" . append_sid("album_cat.$phpEx?cat_id=$cat_id") . "\">", "</a>");
    }
    else
    {
        $template->assign_vars(array(
            'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("album_personal.$phpEx?user_id=$user_id") . '">')
        );

        $message .= "<br /><br />" . sprintf($user->lang['Click_return_personal_gallery'], "<a href=\"" . append_sid("album_personal.$phpEx?user_id=$user_id") . "\">", "</a>");
    }

    $message .= "<br /><br />" . sprintf($user->lang['Click_return_album_index'], "<a href=\"" . append_sid("album.$phpEx") . "\">", "</a>");

    trigger_error($message, E_USER_NOTICE);

}


// +------------------------------------------------------+
// |  Powered by Photo Album 2.x.x (c) 2002-2003 Smartor  |
// +------------------------------------------------------+

?>
