<?php
/***************************************************************************
 *                           album_comment_edit.php
 *                            -------------------
 *   begin                : Saturday, February 15, 2003
 *   copyright            : (C) 2003 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_comment_edit.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/album');

$album_root_path = $phpbb_root_path . 'album/';
include($album_root_path . 'album_constants.' . $phpEx);
include($album_root_path . 'album_common.'.$phpEx);

// Add album to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Photo_Album'],
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album.$phpEx"))
);

// ------------------------------------
// Check feature enabled
// ------------------------------------

if( $album_config['comment'] == 0 )
{
    trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
}


// ------------------------------------
// Check the request
// ------------------------------------
if( isset($_REQUEST['comment_id']) )
{
	$comment_id = request_var('comment_id', 0);
}
else
{
  trigger_error('No category specified', E_USER_ERROR);
}


// ------------------------------------
// Get the comment info
// ------------------------------------
$sql = "SELECT *
        FROM ". ALBUM_COMMENT_TABLE ."
        WHERE comment_id = '$comment_id'";

$result = $db->sql_query($sql);

$thiscomment = $db->sql_fetchrow($result);

if( empty($thiscomment) )
{
    trigger_error('This comment does not exist', E_USER_ERROR);
}


// ------------------------------------
// Get $pic_id from $comment_id
// ------------------------------------

$sql = "SELECT comment_id, comment_pic_id
        FROM ". ALBUM_COMMENT_TABLE ."
        WHERE comment_id = '$comment_id'";

$result = $db->sql_query($sql);

$row = $db->sql_fetchrow($result);

if( empty($row) )
{
    trigger_error('This comment does not exist', E_USER_ERROR);
}

$pic_id = $row['comment_pic_id'];


// ------------------------------------
// Get this pic info
// ------------------------------------

$sql = "SELECT p.*, u.user_id, u.username, COUNT(c.comment_id) as comments_count
        FROM ". ALBUM_TABLE ." AS p
            LEFT JOIN ". USERS_TABLE ." AS u ON p.pic_user_id = u.user_id
            LEFT JOIN ". ALBUM_COMMENT_TABLE ." AS c ON p.pic_id = c.comment_pic_id
        WHERE pic_id = '$pic_id'
        GROUP BY p.pic_id
        LIMIT 1";
$result = $db->sql_query($sql);

$thispic = $db->sql_fetchrow($result);

$cat_id = $thispic['pic_cat_id'];
$user_id = $thispic['pic_user_id'];

$total_comments = $thispic['comments_count'];
$comments_per_page = $config['posts_per_page'];

$pic_filename = $thispic['pic_filename'];
$pic_thumbnail = $thispic['pic_thumbnail'];

if( empty($thispic) )
{
    trigger_error($user->lang['Pic_not_exist'], E_USER_WARNING);
}


// ------------------------------------
// Get the current Category Info
// ------------------------------------

if ($cat_id != PERSONAL_GALLERY)
{
    $sql = "SELECT *
            FROM ". ALBUM_CAT_TABLE ."
            WHERE cat_id = '$cat_id'";
    $result = $db->sql_query($sql);

    $thiscat = $db->sql_fetchrow($result);
}
else
{
    $thiscat = init_personal_gallery_cat($user_id);
}

if (empty($thiscat))
{
    trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
}

//Add category to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $thiscat['cat_title'],
  'U_VIEW_FORUM'  => append_sid("album_cat.$phpEx?cat_id=$cat_id"))
);


// ------------------------------------
// Check the permissions
// ------------------------------------

$album_user_access = album_user_access($thispic['pic_cat_id'], $thiscat, 0, 0, 0, 1, 1, 0);

if( ($album_user_access['comment'] == 0) or ($album_user_access['edit'] == 0) )
{
    if (!$user->data['is_registered'])
    {
        redirect(append_sid("login.$phpEx?redirect=album_comment_edit.$phpEx?comment_id=$comment_id"));
    }
    else
    {
        trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
    }
}
else
{    
    if( (!$album_user_access['moderator']) or ($auth->acl_get('a_')) )
    {
        if ($thiscomment['comment_user_id'] != $user->data['user_id'])
        {
            trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
        }
    }
}


/*
+----------------------------------------------------------
| Main work here...
+----------------------------------------------------------
*/


if( !isset($_POST['comment']) )
{
    /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
               Comments Screen
       ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

    if( ($thispic['pic_user_id'] == ALBUM_GUEST) or ($thispic['username'] == '') )
    {
        $poster = ($thispic['pic_username'] == '') ? $user->lang['Guest'] : $thispic['pic_username'];
    }
    else
    {
        $poster = '<a href="'. append_sid("memberlist.$phpEx?mode=viewprofile&amp;".'u='. $thispic['user_id']) .'">'. $thispic['username'] .'</a>';
    }

    //
    // Start output of page
    //
    
    $template->assign_block_vars('switch_comment_post', array());

    $template->assign_vars(array(
        'CAT_TITLE' => $thiscat['cat_title'],
        'U_VIEW_CAT' => ($cat_id != PERSONAL_GALLERY) ? append_sid("album_cat.$phpEx?cat_id=$cat_id") : append_sid("album_personal.$phpEx?user_id=$user_id"),

        'U_THUMBNAIL' => append_sid("album_thumbnail.$phpEx?pic_id=$pic_id"),
        'U_PIC' => append_sid("album_pic.$phpEx?pic_id=$pic_id"),

        'PIC_TITLE' => $thispic['pic_title'],
        'PIC_DESC' => nl2br($thispic['pic_desc']),
        'POSTER' => $poster,
        'PIC_TIME' => $user->format_date($thispic['pic_time']),
        'PIC_VIEW' => $thispic['pic_view_count'],
        'PIC_COMMENTS' => $total_comments,
        'S_MESSAGE' => $thiscomment['comment_text'],

        'L_PIC_TITLE' => $user->lang['Pic_Title'],
        'L_PIC_DESC' => $user->lang['Pic_Desc'],
        'L_POSTER' => $user->lang['Poster'],
        'L_POSTED' => $user->lang['Posted'],
        'L_VIEW' => $user->lang['View'],
        'L_COMMENTS' => $user->lang['Comments'],

        'L_POST_YOUR_COMMENT' => $user->lang['Post_your_comment'],
        'L_MESSAGE' => $user->lang['Message'],
        'L_USERNAME' => $user->lang['Username'],
        'L_COMMENT_NO_TEXT' => $user->lang['Comment_no_text'],
        'L_COMMENT_TOO_LONG' => $user->lang['Comment_too_long'],
        'L_MAX_LENGTH' => $user->lang['Max_length'],
        'S_MAX_LENGTH' => $album_config['desc_length'],

        'L_SUBMIT' => $user->lang['Submit'],

        'S_ALBUM_ACTION' => append_sid("album_comment_edit.$phpEx?comment_id=$comment_id")
        )
    );

    //
    // Generate the page
    //
    page_header($user->lang['Photo_Album']);

    $template->set_filenames(array(
        'body' => 'album/album_comment_body.html')
    );

    page_footer();
}
else
{
    /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
              Comment Submited
       ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

    $comment_text = str_replace("\'", "''", htmlspecialchars(substr(trim(request_var('comment', '')), 0, $album_config['desc_length'])));

    if( empty($comment_text) )
    {
        trigger_error($user->lang['Comment_no_text'], E_USER_WARNING);
    }


    // --------------------------------
    // Prepare variables
    // --------------------------------

    $comment_edit_time = time();
    $comment_edit_user_id = $user->data['user_id'];


    // --------------------------------
    // Update the DB
    // --------------------------------

    $sql = "UPDATE ". ALBUM_COMMENT_TABLE ."
            SET comment_text = '$comment_text', comment_edit_time = '$comment_edit_time', comment_edit_count = comment_edit_count + 1, comment_edit_user_id = '$comment_edit_user_id'
            WHERE comment_id = '$comment_id'";

    $result = $db->sql_query($sql);


    // --------------------------------
    // Complete... now send a message to user
    // --------------------------------

    $template->assign_vars(array(
        'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("album_comment.$phpEx?comment_id=$comment_id") . '#'.$comment_id.'">')
    );

    $message = $user->lang['Stored'] . "<br /><br />" . sprintf($user->lang['Click_view_message'], "<a href=\"" . append_sid("album_comment.$phpEx?comment_id=$comment_id") . "#$comment_id\">", "</a>") . "<br /><br />" . sprintf($user->lang['Click_return_album_index'], "<a href=\"" . append_sid("album.$phpEx") . "\">", "</a>");

    trigger_error($message, E_USER_NOTICE);
}


// +------------------------------------------------------+
// |  Powered by Photo Album 2.x.x (c) 2002-2003 Smartor  |
// +------------------------------------------------------+

?>
