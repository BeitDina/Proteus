<?php
/***************************************************************************
 *                               album_pic.php
 *                            -------------------
 *   begin                : Wednesday, February 05, 2003
 *   copyright            : (C) 2003 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_pic.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/album');

$album_root_path = $phpbb_root_path . 'album/';
include($album_root_path . 'album_constants.' . $phpEx);
include($album_root_path . 'album_common.'.$phpEx);

// Add album to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Photo_Album'],
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album.$phpEx"))
);

// ------------------------------------
// Check the request
// ------------------------------------

if( isset($_REQUEST['pic_id']) )
{
	$pic_id = request_var('pic_id', 0);
}
else
{
  trigger_error('No pics specified', E_USER_ERROR);
}

// ------------------------------------
// Get this pic info
// ------------------------------------

$sql = "SELECT *
    FROM ". ALBUM_TABLE ."
    WHERE pic_id = '$pic_id'";
$result = $db->sql_query($sql);

$thispic = $db->sql_fetchrow($result);

$cat_id = $thispic['pic_cat_id'];
$user_id = $thispic['pic_user_id'];

$pic_filetype = substr($thispic['pic_filename'], strlen($thispic['pic_filename']) - 4, 4);
$pic_filename = $thispic['pic_filename'];
$pic_thumbnail = $thispic['pic_thumbnail'];

if( empty($thispic) or !file_exists(ALBUM_UPLOAD_PATH . $pic_filename) )
{
  trigger_error($user->lang['Pic_not_exist'], E_USER_WARNING);
}


// ------------------------------------
// Get the current Category Info
// ------------------------------------

if ($cat_id != PERSONAL_GALLERY)
{
  $sql = "SELECT *
      FROM ". ALBUM_CAT_TABLE ."
      WHERE cat_id = '$cat_id'";
  $result = $db->sql_query($sql);

  $thiscat = $db->sql_fetchrow($result);
}
else
{
  $thiscat = init_personal_gallery_cat($user_id);
}

if (empty($thiscat))
{
  trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
}

//Add category to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $thiscat['cat_title'],
  'U_VIEW_FORUM'  => append_sid("album_cat.$phpEx?cat_id=$cat_id"))
);

// ------------------------------------
// Check the permissions
// ------------------------------------

$album_user_access = album_user_access($cat_id, $thiscat, 1, 0, 0, 0, 0, 0); // VIEW
if ($album_user_access['view'] == 0)
{
  trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
}


// ------------------------------------
// Check Pic Approval
// ------------------------------------

if (!$auth->acl_get('a_'))
{
  if( ($thiscat['cat_approval'] == ADMIN) or (($thiscat['cat_approval'] == MOD) and !$album_user_access['moderator']) )
  {
    if ($thispic['pic_approval'] != 1)
    {
      trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
    }
  }
}


// ------------------------------------
// Check hotlink
// ------------------------------------

if( ($album_config['hotlink_prevent'] == 1) and (isset($_SERVER['HTTP_REFERER'])) )
{
  $check_referer = explode('?', $_SERVER['HTTP_REFERER']);
  $check_referer = trim($check_referer[0]);

  $good_referers = array();

  if ($album_config['hotlink_allowed'] != '')
  {
    $good_referers = explode(',', $album_config['hotlink_allowed']);
  }

  $good_referers[] = $config['server_name'] . $config['script_path'];

  $errored = TRUE;

  for ($i = 0; $i < count($good_referers); $i++)
  {
    $good_referers[$i] = trim($good_referers[$i]);

    if( (strstr($check_referer, $good_referers[$i])) and ($good_referers[$i] != '') )
    {
      $errored = FALSE;
    }
  }

  if ($errored)
  {
    trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
  }
}


/*
+----------------------------------------------------------
| Main work here...
+----------------------------------------------------------
*/


// ------------------------------------
// Increase view counter
// ------------------------------------

$sql = "UPDATE ". ALBUM_TABLE ."
    SET pic_view_count = pic_view_count + 1
    WHERE pic_id = '$pic_id'";
$result = $db->sql_query($sql);


// ------------------------------------
// Okay, now we can send image to the browser
// ------------------------------------

switch ( $pic_filetype )
{
  case '.png':
    header('Content-type: image/png');
    break;
  case '.gif':
    header('Content-type: image/gif');
    break;
  case '.jpg':
    header('Content-type: image/jpeg');
    break;
  default:
    die('The filename data in the DB was corrupted');
}

readfile(ALBUM_UPLOAD_PATH  . $thispic['pic_filename']);

exit;


// +------------------------------------------------------+
// |  Powered by Photo Album 2.x.x (c) 2002-2003 Smartor  |
// +------------------------------------------------------+

?>
