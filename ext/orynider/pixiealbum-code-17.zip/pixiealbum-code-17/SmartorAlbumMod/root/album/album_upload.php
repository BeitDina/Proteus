<?php
/***************************************************************************
 *                             album_upload.php
 *                            -------------------
 *   begin                : Wednesday, February 05, 2003
 *   copyright            : (C) 2003 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_upload.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
define('IN_PHPBB', true);
$phpbb_root_path = '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/album');

$album_root_path = $phpbb_root_path . 'album/';
include($album_root_path . 'album_constants.' . $phpEx);
include($album_root_path . 'album_common.'.$phpEx);

// Add album to navlinks
$template->assign_block_vars('navlinks', array(
 	'FORUM_NAME'  => $user->lang['Photo_Album'],
	'U_VIEW_FORUM'  => append_sid("{$album_root_path}album.$phpEx"))
);

// ------------------------------------
// Check the request
// ------------------------------------

if( isset($_REQUEST['cat_id']) )
{
	$cat_id = request_var('cat_id', 0);
}
else
{
 	trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
}
//
// END check request
//


// ------------------------------------
// Get the current Category Info
// ------------------------------------

if ($cat_id != PERSONAL_GALLERY)
{
  $sql = "SELECT c.*, COUNT(p.pic_id) AS count
      FROM ". ALBUM_CAT_TABLE ." AS c
        LEFT JOIN ". ALBUM_TABLE ." AS p ON c.cat_id = p.pic_cat_id
      WHERE c.cat_id = '$cat_id'
      GROUP BY c.cat_id
      LIMIT 1";
  $result = $db->sql_query($sql);

  $thiscat = $db->sql_fetchrow($result);
}
else
{
  $thiscat = init_personal_gallery_cat($user->data['user_id']);
}

$current_pics = $thiscat['count'];

if (empty($thiscat))
{
  trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
}

//Add category to navlinks
$template->assign_block_vars('navlinks', array(
	'FORUM_NAME'  => $thiscat['cat_title'],
	'U_VIEW_FORUM'  => ($thiscat['cat_id'] == PERSONAL_GALLERY) ? append_sid("album_personal.$phpEx") : append_sid("album_cat.$phpEx?cat_id=$cat_id") )
);

// ------------------------------------
// Check the permissions
// ------------------------------------

$album_user_access = album_user_access($cat_id, $thiscat, 0, 1, 0, 0, 0, 0); // UPLOAD

if ($album_user_access['upload'] == 0)
{
  if (!$user->data['is_registered'])
  {
    redirect(append_sid("login.$phpEx?redirect=album_upload.$phpEx?cat_id=$cat_id"));
  }
  else
  {
    trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
  }
}


/*
+----------------------------------------------------------
| Upload Quota Check
+----------------------------------------------------------
*/

if ($cat_id != PERSONAL_GALLERY)
{
  // ------------------------------------
  // Check Album Configuration Quota
  // ------------------------------------

  if ($album_config['max_pics'] >= 0)
  {
    //
    // $current_pics was set at "Get the current Category Info"
    //
    if( $current_pics >= $album_config['max_pics'] )
    {
      trigger_error($user->lang['Album_reached_quota'], E_USER_WARNING);
    }
  }


  // ------------------------------------
  // Check User Limit
  // ------------------------------------

  $check_user_limit = FALSE;

  if( (!$auth->acl_get('a_')) and ($user->data['is_registered']) )
  {
    if ($album_user_access['moderator'])
    {
      if ($album_config['mod_pics_limit'] >= 0)
      {
        $check_user_limit = 'mod_pics_limit';
      }
    }
    else
    {
      if ($album_config['user_pics_limit'] >= 0)
      {
        $check_user_limit = 'user_pics_limit';
      }
    }
  }

  // Do the check here
  if ($check_user_limit != FALSE)
  {
    $sql = "SELECT COUNT(pic_id) AS count
        FROM ". ALBUM_TABLE ."
        WHERE pic_user_id = '". $userdata['user_id'] ."'
          AND pic_cat_id = '$cat_id'";
    $result = $db->sql_query($sql);

    $row = $db->sql_fetchrow($result);
    $own_pics = $row['count'];

    if( $own_pics >= $album_config[$check_user_limit] )
    {
      trigger_error($user->lang['User_reached_pics_quota'], E_USER_WARNING);
    }
  }
}
else
{
  if( ($current_pics >= $album_config['personal_gallery_limit']) and ($album_config['personal_gallery_limit'] >= 0) )
  {
    trigger_error($user->lang['Album_reached_quota'], E_USER_WARNING);
  }
}

/*
+----------------------------------------------------------
| Main work here...
+----------------------------------------------------------
*/

if( !isset($_POST['pic_title']) ) // is it not submitted?
{
  // --------------------------------
  // Build categories select
  // --------------------------------
  $sql = "SELECT *
      FROM " . ALBUM_CAT_TABLE ."
      ORDER BY cat_order ASC";
  $result = $db->sql_query($sql);

  $catrows = array();

  while( $row = $db->sql_fetchrow($result) )
  {
    $thiscat_access = album_user_access($row['cat_id'], $row, 0, 1, 0, 0, 0, 0); // UPLOAD

    if ($thiscat_access['upload'] == 1)
    {
      $catrows[] = $row;
    }
  }

  $select_cat = '<select name="cat_id">';

  if ($cat_id == PERSONAL_GALLERY)
  {
    $select_cat .= '<option value="$cat_id" selected="selected">';
    $select_cat .= $user->lang['Personal_Gallery_Of_User'] . ' ' . $user->data['username'];
    $select_cat .= '</option>';
  }

  for ($i = 0; $i < count($catrows); $i++)
  {
    $select_cat .= '<option value="'. $catrows[$i]['cat_id'] .'" ';
    $select_cat .= ($cat_id == $catrows[$i]['cat_id']) ? 'selected="selected"' : '';
    $select_cat .= '>'. $catrows[$i]['cat_title'] .'</option>';
  }

  $select_cat .= '</select>';

  //
  // Start output of page
  //
  
  $template->assign_vars(array(
    'U_VIEW_CAT' => ($cat_id != PERSONAL_GALLERY) ? append_sid("album_cat.$phpEx?cat_id=$cat_id") : append_sid("album_personal.$phpEx"),
    'CAT_TITLE' => $thiscat['cat_title'],

    'L_UPLOAD_PIC' => $user->lang['Upload_Pic'],

    'L_USERNAME' => $user->lang['USERNAME'],
    'L_PIC_TITLE' => $user->lang['Pic_Title'],

    'L_PIC_DESC' => $user->lang['Pic_Desc'],
    'L_PLAIN_TEXT_ONLY' => $user->lang['Plain_text_only'],
    'L_MAX_LENGTH' => $user->lang['Max_length'],
    'S_PIC_DESC_MAX_LENGTH' => $album_config['desc_length'],

    'L_UPLOAD_PIC_FROM_MACHINE' => $user->lang['Upload_pic_from_machine'],
    'L_UPLOAD_TO_CATEGORY' => $user->lang['Upload_to_Category'],

    'SELECT_CAT' => $select_cat,

    'L_MAX_FILESIZE' => $user->lang['Max_file_size'],
    'S_MAX_FILESIZE' => $album_config['max_file_size'],

    'L_MAX_WIDTH' => $user->lang['Max_width'],
    'L_MAX_HEIGHT' => $user->lang['Max_height'],

    'S_MAX_WIDTH' => $album_config['max_width'],
    'S_MAX_HEIGHT' => $album_config['max_height'],

    'L_ALLOWED_JPG' => $user->lang['JPG_allowed'],
    'L_ALLOWED_PNG' => $user->lang['PNG_allowed'],
    'L_ALLOWED_GIF' => $user->lang['GIF_allowed'],

    'S_JPG' => ($album_config['jpg_allowed'] == 1) ? $user->lang['Yes'] : $user->lang['No'],
    'S_PNG' => ($album_config['png_allowed'] == 1) ? $user->lang['Yes'] : $user->lang['No'],
    'S_GIF' => ($album_config['gif_allowed'] == 1) ? $user->lang['Yes'] : $user->lang['No'],

    'L_UPLOAD_NO_TITLE' => $user->lang['Upload_no_title'],
    'L_UPLOAD_NO_FILE' => $user->lang['Upload_no_file'],
    'L_DESC_TOO_LONG' => $user->lang['Desc_too_long'],

    // Manual Thumbnail
    'L_UPLOAD_THUMBNAIL' => $user->lang['Upload_thumbnail'],
    'L_UPLOAD_THUMBNAIL_EXPLAIN' => $user->lang['Upload_thumbnail_explain'],
    'L_THUMBNAIL_SIZE' => $user->lang['Thumbnail_size'],
    'S_THUMBNAIL_SIZE' => $album_config['thumbnail_size'],

    'L_RESET' => $user->lang['Reset'],
    'L_SUBMIT' => $user->lang['Submit'],

    'S_ALBUM_ACTION' => append_sid("album_upload.$phpEx?cat_id=$cat_id"),
    )
  );

  if ($album_config['gd_version'] == 0)
  {
    $template->assign_block_vars('switch_manual_thumbnail', array());
  }

  //
  // Generate the page
  //
  page_header($user->lang['Photo_Album']);

  $template->set_filenames(array(
    'body' => 'album/album_upload_body.html')
  );

  page_footer();
}
else
{
  // --------------------------------
  // Check posted info
  // --------------------------------

  $pic_title = str_replace("\'", "''", htmlspecialchars(trim(request_var('pic_title',''))));

  $pic_desc = str_replace("\'", "''", htmlspecialchars(substr(trim(request_var('pic_desc','')), 0, $album_config['desc_length'])));

  $pic_username = (!$userdata['is_registered']) ? substr(str_replace("\'", "''", htmlspecialchars(trim(request_var('pic_username','')))), 0, 32) : str_replace("'", "''", $user->data['username']);

  if( empty($pic_title) )
  {
    trigger_error($user->lang['Missed_pic_title'], E_USER_WARNING);
  }

  if( !isset($HTTP_POST_FILES['pic_file']) )
  {
    trigger_error($user->lang['Bad Upload'], E_USER_WARNING);
  }


  // --------------------------------
  // Check username for guest posting
  // --------------------------------

  if (!$userdata['is_registered'])
  {
    if ($pic_username != '')
    {
      $result = validate_username($pic_username);
      if ( $result['error'] )
      {
        trigger_error($result['error_msg'], E_USER_WARNING);
      }
    }
  }  


  // --------------------------------
  // Get File Upload Info
  // --------------------------------

  $filetype = $HTTP_POST_FILES['pic_file']['type'];
  $filesize = $HTTP_POST_FILES['pic_file']['size'];
  $filetmp = $HTTP_POST_FILES['pic_file']['tmp_name'];

  if ($album_config['gd_version'] == 0)
  {
    $thumbtype = $HTTP_POST_FILES['pic_thumbnail']['type'];
    $thumbsize = $HTTP_POST_FILES['pic_thumbnail']['size'];
    $thumbtmp = $HTTP_POST_FILES['pic_thumbnail']['tmp_name'];
  }


  // --------------------------------
  // Prepare variables
  // --------------------------------

  $pic_time = time();
  $pic_user_id = $user->data['user_id'];
  $pic_user_ip = $user->data['session_ip'];


  // --------------------------------
  // Check file size
  // --------------------------------

  if( ($filesize == 0) or ($filesize > $album_config['max_file_size']) )
  {
    trigger_error($user->lang['Bad_upload_file_size'], E_USER_WARNING);
  }

  if ($album_config['gd_version'] == 0)
  {
    if( ($thumbsize == 0) or ($thumbsize > $album_config['max_file_size']) )
    {
      trigger_error($user->lang['Bad_upload_file_size'], E_USER_WARNING);
    }
  }


  // --------------------------------
  // Check file type
  // --------------------------------

  switch ($filetype)
  {
    case 'image/jpeg':
    case 'image/jpg':
    case 'image/pjpeg':
      if ($album_config['jpg_allowed'] == 0)
      {
        trigger_error($user->lang['Not_allowed_file_type'], E_USER_WARNING);
      }
      $pic_filetype = '.jpg';
      break;

    case 'image/png':
    case 'image/x-png':
      if ($album_config['png_allowed'] == 0)
      {
        trigger_error($user->lang['Not_allowed_file_type'], E_USER_WARNING);
      }
      $pic_filetype = '.png';
      break;

    case 'image/gif':
      if ($album_config['gif_allowed'] == 0)
      {
        trigger_error($user->lang['Not_allowed_file_type'], E_USER_WARNING);
      }
      $pic_filetype = '.gif';
      break;
    default:
      trigger_error($user->lang['Not_allowed_file_type'], E_USER_WARNING);
  }

  if ($album_config['gd_version'] == 0)
  {
    if ($filetype != $thumbtype)
    {
      trigger_error($user->lang['Filetype_and_thumbtype_do_not_match'], E_USER_WARNING);
    }
  }


  // --------------------------------
  // Generate filename
  // --------------------------------

  srand((double)microtime()*1000000);  // for older than version 4.2.0 of PHP

  do
  {
    $pic_filename = md5(uniqid(rand())) . $pic_filetype;
  }
  while( file_exists(ALBUM_UPLOAD_PATH . $pic_filename) );

  if ($album_config['gd_version'] == 0)
  {
    $pic_thumbnail = $pic_filename;
  }


  // --------------------------------
  // Move this file to upload directory
  // --------------------------------

  $ini_val = ( @phpversion() >= '4.0.0' ) ? 'ini_get' : 'get_cfg_var';

  if ( @$ini_val('open_basedir') != '' )
  {
    if ( @phpversion() < '4.0.3' )
    {
      trigger_error('open_basedir is set and your PHP version does not allow move_uploaded_file<br /><br />Please contact your server admin', E_USER_ERROR);
    }

    $move_file = 'move_uploaded_file';
  }
  else
  {
    $move_file = 'copy';
  }

  $move_file($filetmp, ALBUM_UPLOAD_PATH . $pic_filename);

  @chmod(ALBUM_UPLOAD_PATH . $pic_filename, 0777);

  if ($album_config['gd_version'] == 0)
  {
    $move_file($thumbtmp, ALBUM_CACHE_PATH . $pic_thumbnail);

    @chmod(ALBUM_CACHE_PATH . $pic_thumbnail, 0777);
  }


  // --------------------------------
  // Well, it's an image. Check its image size
  // --------------------------------

  $pic_size = getimagesize(ALBUM_UPLOAD_PATH . $pic_filename);

  $pic_width = $pic_size[0];
  $pic_height = $pic_size[1];

  if ( ($pic_width > $album_config['max_width']) or ($pic_height > $album_config['max_height']) )
  {
    @unlink(ALBUM_UPLOAD_PATH . $pic_filename);

    if ($album_config['gd_version'] == 0)
    {
      @unlink(ALBUM_CACHE_PATH . $pic_thumbnail);
    }

    trigger_error($user->lang['Upload_image_size_too_big'], E_USER_WARNING);
  }

  if ($album_config['gd_version'] == 0)
  {
    $thumb_size = getimagesize(ALBUM_CACHE_PATH . $pic_thumbnail);

    $thumb_width = $thumb_size[0];
    $thumb_height = $thumb_size[1];

    if ( ($thumb_width > $album_config['thumbnail_size']) or ($thumb_height > $album_config['thumbnail_size']) )
    {
      @unlink(ALBUM_UPLOAD_PATH . $pic_filename);

      @unlink(ALBUM_CACHE_PATH . $pic_thumbnail);

      trigger_error($user->lang['Upload_thumbnail_size_too_big'], E_USER_WARNING);
    }
  }


  // --------------------------------
  // This image is okay, we can cache its thumbnail now
  // --------------------------------

   if( ($album_config['thumbnail_cache'] == 1) and ($album_config['gd_version'] > 0) ) 
   { 
      $gd_errored = FALSE; 

      switch ($pic_filetype) 
      { 
         case '.jpg': 
            $read_function = 'imagecreatefromjpeg'; 
            break; 
         case '.png': 
            $read_function = 'imagecreatefrompng'; 
            break; 
         case '.gif': 
            $read_function = 'imagecreatefromgif'; 
            break;             
      }

    $src = @$read_function(ALBUM_UPLOAD_PATH  . $pic_filename);

    if (!$src)
    {
      $gd_errored = TRUE;
      $pic_thumbnail = '';
    }
    else if( ($pic_width > $album_config['thumbnail_size']) or ($pic_height > $album_config['thumbnail_size']) )
    {
      // Resize it
      if ($pic_width > $pic_height)
      {
        $thumbnail_width = $album_config['thumbnail_size'];
        $thumbnail_height = $album_config['thumbnail_size'] * ($pic_height/$pic_width);
      }
      else
      {
        $thumbnail_height = $album_config['thumbnail_size'];
        $thumbnail_width = $album_config['thumbnail_size'] * ($pic_width/$pic_height);
      }

      $thumbnail = ($album_config['gd_version'] == 1) ? @imagecreate($thumbnail_width, $thumbnail_height) : @imagecreatetruecolor($thumbnail_width, $thumbnail_height);

      $resize_function = ($album_config['gd_version'] == 1) ? 'imagecopyresized' : 'imagecopyresampled';

      @$resize_function($thumbnail, $src, 0, 0, 0, 0, $thumbnail_width, $thumbnail_height, $pic_width, $pic_height);
    }
    else
    {
      $thumbnail = $src;
    }

    if (!$gd_errored)
    {
      $pic_thumbnail = $pic_filename;

      // Write to disk
      switch ($pic_filetype)
      {
        case '.jpg':
          @imagejpeg($thumbnail, ALBUM_CACHE_PATH . $pic_thumbnail, $album_config['thumbnail_quality']);
          break;
        case '.png':
          @imagepng($thumbnail, ALBUM_CACHE_PATH . $pic_thumbnail);
          break;
        case '.gif':
          @imagegif($thumbnail, ALBUM_CACHE_PATH . $pic_thumbnail);
          break;
      }

      @chmod(ALBUM_CACHE_PATH . $pic_thumbnail, 0777);

    } // End IF $gd_errored

  } // End Thumbnail Cache
  else if ($album_config['gd_version'] > 0)
  {
    $pic_thumbnail = '';
  }

  // --------------------------------
  // Check Pic Approval
  // --------------------------------

  $pic_approval = ($thiscat['cat_approval'] == 0) ? 1 : 0;


  // --------------------------------
  // Insert into DB
  // --------------------------------
    // Note: phpBB is now returning normal dot ip
    // to keep code we will let MYSQL do the work
    // inet_ntoa(conv('7F000001',16,10))
    // conv(inet_aton('127.0.0.1'),10,16)
  $sql = "INSERT INTO ". ALBUM_TABLE ." (pic_filename, pic_thumbnail, pic_title, pic_desc, pic_user_id, pic_user_ip, pic_username, pic_time, pic_cat_id, pic_approval)
      VALUES ('$pic_filename', '$pic_thumbnail', '$pic_title', '$pic_desc', '$pic_user_id', conv(inet_aton('$pic_user_ip'),10,16), '$pic_username', '$pic_time', '$cat_id', '$pic_approval')";
  if( !$result = $db->sql_query($sql) )
  {
    trigger_error('Could not insert new entry', E_USER_ERROR);
  }


  // --------------------------------
  // Complete... now send a message to user
  // --------------------------------

  if ($thiscat['cat_approval'] == 0)
  {
    $message = $user->lang['Album_upload_successful'];
  }
  else
  {
    $message = $user->lang['Album_upload_need_approval'];
  }

  if ($cat_id != PERSONAL_GALLERY)
  {
    if ($thiscat['cat_approval'] == 0)
    {
      $template->assign_vars(array(
        'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("album_cat.$phpEx?cat_id=$cat_id") . '">')
      );
    }

    $message .= "<br /><br />" . sprintf($user->lang['Click_return_category'], "<a href=\"" . append_sid("album_cat.$phpEx?cat_id=$cat_id") . "\">", "</a>");
  }
  else
  {
    if ($thiscat['cat_approval'] == 0)
    {
      $template->assign_vars(array(
        'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("album_personal.$phpEx") . '">')
      );
    }

    $message .= "<br /><br />" . sprintf($user->lang['Click_return_personal_gallery'], "<a href=\"" . append_sid("album_personal.$phpEx") . "\">", "</a>");
  }


  $message .= "<br /><br />" . sprintf($user->lang['Click_return_album_index'], "<a href=\"" . append_sid("album.$phpEx") . "\">", "</a>");

  trigger_error($message, E_USER_NOTICE);
}


// +------------------------------------------------------+
// |  Powered by Photo Album 2.x.x (c) 2002-2003 Smartor  |
// +------------------------------------------------------+

?>
