<?php
/***************************************************************************
 *                 album_common.php
 *                            -------------------
 *   begin                : Saturday, February 01, 2003
 *   copyright            : (C) 2003 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_common.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

if ( !defined('IN_PHPBB') )
{
  die('Hacking attempt');
}

// Include Language
$user->add_lang('mods/album');

// Get Album Config
$sql = "SELECT *
    FROM ". ALBUM_CONFIG_TABLE;
$result = $db->sql_query($sql);

while( $row = $db->sql_fetchrow($result) )
{
  $album_config_name = $row['config_name'];
  $album_config_value = $row['config_value'];
  $album_config[$album_config_name] = $album_config_value;
}

//
// Set ALBUM Version
//
$template->assign_vars(array(
  'ALBUM_VERSION' => '2' . $album_config['album_version']
  )
);

include($album_root_path . 'album_functions.' . $phpEx);

?>
