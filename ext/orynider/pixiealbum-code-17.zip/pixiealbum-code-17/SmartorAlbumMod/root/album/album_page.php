<?php
/***************************************************************************
 *                              album_page.php
 *                            -------------------
 *   begin                : Sunday, February 23, 2003
 *   copyright            : (C) 2003 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_page.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/album');

$album_root_path = $phpbb_root_path . 'album/';
include($album_root_path . 'album_constants.' . $phpEx);
include($album_root_path . 'album_common.'.$phpEx);

// Add album to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Photo_Album'],
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album.$phpEx"))
);

// ------------------------------------
// Check the request
// ------------------------------------

if( isset($_REQUEST['pic_id']) )
{
	$pic_id = request_var('pic_id', 0);
}
else
{
  trigger_error('No pics specified', E_USER_ERROR);
}

// ------------------------------------ 
// PREVIOUS & NEXT 
// ------------------------------------ 

if( isset($_GET['mode']) ) 
{ 
        if( ($_GET['mode'] == 'next') or ($_GET['mode'] == 'previous') ) 
        { 
                $sql = "SELECT pic_id, pic_cat_id, pic_user_id 
                                FROM ". ALBUM_TABLE ." 
                                WHERE pic_id = $pic_id"; 

                $result = $db->sql_query($sql);
      
                $row = $db->sql_fetchrow($result);
                $cur_pic_cat = $row['pic_cat_id'];

                if( empty($row) ) 
                { 
                        trigger_error('Bad pic_id', E_USER_ERROR);
                } 

                $sql = "SELECT new.pic_id, new.pic_time 
                                FROM ". ALBUM_TABLE ." AS new, ". ALBUM_TABLE ." AS cur 
                                WHERE cur.pic_id = $pic_id 
                                        AND new.pic_id <> cur.pic_id 
                                        AND new.pic_cat_id = cur.pic_cat_id"; 

                $sql .= ($_GET['mode'] == 'next') ? " AND new.pic_time >= cur.pic_time" : " AND new.pic_time <= cur.pic_time"; 

                $sql .= ($row['pic_cat_id'] == PERSONAL_GALLERY) ? " AND new.pic_user_id = cur.pic_user_id" : ""; 

                $sql .= ($_GET['mode'] == 'next') ? " ORDER BY pic_time ASC LIMIT 1" : " ORDER BY pic_time DESC LIMIT 1"; 

                $result = $db->sql_query($sql);

                $row = $db->sql_fetchrow($result); 

                $sql = "SELECT min(pic_id), max(pic_id)
                                FROM ". ALBUM_TABLE ."
                WHERE pic_cat_id = $cur_pic_cat"; 

                $result = $db->sql_query($sql);

                $next = $db->sql_fetchrow($result);
        
				$first_pic = $next['min(pic_id)'];
				$last_pic = $next['max(pic_id)'];
				
				if( empty($row) AND ($_GET['mode'] == 'next')) 
				{               
					redirect(append_sid("album_page.$phpEx?pic_id=$first_pic"));
				} 
				if( empty($row) AND ($HTTP_GET_VARS['mode'] == 'previous')) 
				{ 
					redirect(append_sid("album_page.$phpEx?pic_id=$last_pic"));
				} 
            
                $pic_id = $row['pic_id']; // NEW pic_id 
        } 
}


// ------------------------------------
// Get this pic info
// ------------------------------------

$sql = "SELECT p.*, u.user_id, u.username, r.rate_pic_id, AVG(r.rate_point) AS rating, COUNT(DISTINCT c.comment_id) AS comments
    FROM ". ALBUM_TABLE ." AS p
      LEFT JOIN ". USERS_TABLE ." AS u ON p.pic_user_id = u.user_id
      LEFT JOIN ". ALBUM_RATE_TABLE ." AS r ON p.pic_id = r.rate_pic_id
      LEFT JOIN ". ALBUM_COMMENT_TABLE ." AS c ON p.pic_id = c.comment_pic_id
    WHERE pic_id = '$pic_id'
    GROUP BY p.pic_id";
$result = $db->sql_query($sql);

$thispic = $db->sql_fetchrow($result);

$cat_id = $thispic['pic_cat_id'];
$user_id = $thispic['pic_user_id'];

if( empty($thispic) or !file_exists(ALBUM_UPLOAD_PATH . $pic_filename) )
{
  trigger_error($user->lang['Pic_not_exist'], E_USER_WARNING);
}


// ------------------------------------
// Get the current Category Info
// ------------------------------------

if ($cat_id != PERSONAL_GALLERY)
{
  $sql = "SELECT *
      FROM ". ALBUM_CAT_TABLE ."
      WHERE cat_id = '$cat_id'";
  $result = $db->sql_query($sql);

  $thiscat = $db->sql_fetchrow($result);
}
else
{
  $thiscat = init_personal_gallery_cat($user_id);
}

if (empty($thiscat))
{
  trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
}

//Add category to navlinks
$template->assign_block_vars('navlinks', array(
	'FORUM_NAME'  => $thiscat['cat_title'],
	'U_VIEW_FORUM'  => ($thiscat['cat_id'] == PERSONAL_GALLERY) ? append_sid("album_personal.$phpEx?user_id=" . $thispic['pic_user_id']) : append_sid("album_cat.$phpEx?cat_id=$cat_id") )
);

// ------------------------------------
// Check the permissions
// ------------------------------------

$album_user_access = album_user_access($cat_id, $thiscat, 1, 0, 0, 0, 0, 0); // VIEW

if ($album_user_access['view'] == 0)
{
  if (!$user->data['is_registered'])
  {
    redirect(append_sid("login.$phpEx?redirect=album_page.$phpEx?pic_id=$pic_id"));
  }
  else
  {
    trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
  }
}



// ------------------------------------
// Check Pic Approval
// ------------------------------------

if (!$auth->acl_get('a_'))
{
  if( ($thiscat['cat_approval'] == ADMIN) or (($thiscat['cat_approval'] == MOD) and !$album_user_access['moderator']) )
  {
    if ($thispic['pic_approval'] != 1)
    {
      trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
    }
  }
}


/*
+----------------------------------------------------------
| Main work here...
+----------------------------------------------------------
*/

if( ($thispic['pic_user_id'] == ALBUM_GUEST) or ($thispic['username'] == '') )
{
  $poster = ($thispic['pic_username'] == '') ? $lang['Guest'] : $thispic['pic_username'];
}
else
{
  $poster = '<a href="'. append_sid("{$phpbb_root_path}memberlist.$phpEx?mode=viewprofile&amp;".'u='. $thispic['user_id']) .'">'. $thispic['username'] .'</a>';
}


$template->assign_vars(array(
  'CAT_TITLE' => $thiscat['cat_title'],
  'U_VIEW_CAT' => ($cat_id != PERSONAL_GALLERY) ? append_sid("album_cat.$phpEx?cat_id=$cat_id") : append_sid("album_personal.$phpEx?user_id=$user_id"),

  'U_PIC' => append_sid("album_pic.$phpEx?pic_id=$pic_id"),

  'PIC_TITLE' => $thispic['pic_title'],
  'PIC_DESC' => nl2br($thispic['pic_desc']),

  'POSTER' => $poster,

  'PIC_TIME' => $user->format_date($thispic['pic_time']),

  'PIC_VIEW' => $thispic['pic_view_count'],

  'PIC_RATING' => ($thispic['rating'] != 0) ? round($thispic['rating'], 2) : $user->lang['Not_rated'],

  'PIC_COMMENTS' => $thispic['comments'],

  'U_RATE' => append_sid("album_rate.$phpEx?pic_id=$pic_id"),
  'U_COMMENT' => append_sid("album_comment.$phpEx?pic_id=$pic_id"),

  'U_NEXT' => append_sid("album_page.$phpEx?pic_id=$pic_id&amp;mode=next"),
  'U_PREVIOUS' => append_sid("album_page.$phpEx?pic_id=$pic_id&amp;mode=previous"),

  'L_NEXT' => $user->lang['Next'],
  'L_PREVIOUS' => $user->lang['Previous'],

  'L_RATING' => $user->lang['Rating'],
  'L_PIC_TITLE' => $user->lang['Pic_Title'],
  'L_PIC_DESC' => $user->lang['Pic_Desc'],
  'L_POSTER' => $user->lang['Poster'],
  'L_POSTED' => $user->lang['Posted'],
  'L_VIEW' => $user->lang['View'],
  'L_COMMENTS' => $user->lang['Comments'])
);

if ($album_config['rate'])
{
  $template->assign_block_vars('rate_switch', array());
}

if ($album_config['comment'])
{
  $template->assign_block_vars('comment_switch', array());
}

//
// Generate the page
//
page_header($user->lang['Photo_Album']);

$template->set_filenames(array(
  'body' => 'album/album_page_body.html')
);

page_footer();

// +------------------------------------------------------+
// |  Powered by Photo Album 2.x.x (c) 2002-2003 Smartor  |
// +------------------------------------------------------+

?>
