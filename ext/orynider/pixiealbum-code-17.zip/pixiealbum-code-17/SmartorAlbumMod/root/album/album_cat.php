<?php
/***************************************************************************
 *                               album_cat.php
 *                            -------------------
 *   begin                : Tuesday, February 04, 2003
 *   copyright            : (C) 2003 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_cat.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
define('IN_PHPBB', true);
$phpbb_root_path = '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
include($phpbb_root_path . 'includes/functions_convert.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/album');

$album_root_path = $phpbb_root_path . 'album/';
include($album_root_path . 'album_constants.' . $phpEx);
include($album_root_path . 'album_common.'.$phpEx);

// Add album to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Photo_Album'],
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album.$phpEx"))
);

// ------------------------------------
// Check the request
// ------------------------------------
if( isset($_REQUEST['cat_id']) )
{
    $cat_id = request_var('cat_id', 0);
}
else
{
    trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
}
//
// END check request
//


if ($cat_id == PERSONAL_GALLERY)
{
  redirect(append_sid("album_personal.$phpEx"));
}


// ------------------------------------
// Get this cat info
// ------------------------------------
$sql = "SELECT c.*, COUNT(p.pic_id) AS count
    FROM ". ALBUM_CAT_TABLE ." AS c LEFT JOIN ". ALBUM_TABLE ." AS p ON c.cat_id = p.pic_cat_id
    WHERE c.cat_id <> 0
    GROUP BY c.cat_id
    ORDER BY cat_order";
$result = $db->sql_query($sql);

$thiscat = array(); // this category
$catrows = array(); // all categories for jumpbox

while( $row = $db->sql_fetchrow($result) )
{
  $album_user_access = album_user_access($row['cat_id'], $row, 1, 0, 0, 0, 0, 0); // VIEW
  if ($album_user_access['view'] == 1)
  {
    $catrows[] = $row;

    if( $row['cat_id'] == $cat_id )
    {
      $thiscat = $row;
      $auth_data = album_user_access($cat_id, $row, 1, 1, 1, 1, 1, 1); // ALL
      $total_pics = $thiscat['count'];
    }
  }
}

//
// END cat info
//

//Add category to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $thiscat['cat_title'],
  'U_VIEW_FORUM'  => append_sid("album_cat.$phpEx?cat_id=$cat_id"))
);

// ------------------------------------
// Check permissions
// ------------------------------------
if( !$auth_data['view'] )
{
  if (!$user->data['is_registered'])
  {
    redirect(append_sid("login.$phpEx?redirect=album_cat.$phpEx&cat_id=$cat_id"));    
  }
  else
  {
    trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
  }
}
//
// END check permissions
//


if (empty($thiscat))
{
  trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
}


// ------------------------------------
// Build Auth List
// ------------------------------------
$auth_key = array_keys($auth_data);

$auth_list = '';
for ($i = 0; $i < (count($auth_data) - 1); $i++) // ignore MODERATOR in this loop
{
  //
  // we should skip a loop if RATE and COMMENT is disabled
  //
  if( ( ($album_config['rate'] == 0) and ($auth_key[$i] == 'rate') ) or ( ($album_config['comment'] == 0) and ($auth_key[$i] == 'comment') ) )
  {
    continue;
  }

  $auth_list .= ($auth_data[$auth_key[$i]] == 1) ? $user->lang['Album_'. $auth_key[$i] .'_can'] : $user->lang['Album_'. $auth_key[$i] .'_cannot'];
  $auth_list .= '<br />';
}

// add Moderator Control Panel here
if( $auth_data['moderator'] )
{
  $auth_list .= sprintf($user->lang['Album_moderate_can'], '<a href="'. append_sid("album_modcp.$phpEx?cat_id=$cat_id") .'">', '</a>');
}

//
// END Auth List
//


// ------------------------------------
// Build Moderators List
// ------------------------------------

$grouprows = array();
$moderators_list = '';

if ($thiscat['cat_moderator_groups'] != '')
{
  // Get the namelist of moderator usergroups
  $sql = "SELECT group_id, group_name, group_type
      FROM " . GROUPS_TABLE . "
      WHERE group_type <> ". GROUP_HIDDEN ."
        AND group_id IN (". $thiscat['cat_moderator_groups'] .")
      ORDER BY group_name ASC";
  $result = $db->sql_query($sql);

  while( $row = $db->sql_fetchrow($result) )
  {
    $grouprows[] = $row;
  }

  if( count($grouprows) > 0 )
  {
    for ($j = 0; $j < count($grouprows); $j++)
    {
      $group_link = '<a href="'. append_sid("{$phpbb_root_path}memberlist.$phpEx?mode=group&amp;".'g='. $grouprows[$j]['group_id']) .'">'. $grouprows[$j]['group_name'] .'</a>';

      $moderators_list .= ($moderators_list == '') ? $group_link : ', ' . $group_link;
    }
  }
}

if( empty($moderators_list) )
{
  $moderators_list = $user->lang['None'];
}
//
// END Moderator List
//


// ------------------------------------
// Build the thumbnail page
// ------------------------------------

$start = request_var('start', 0);
$sort_method = request_var('sort_method', $album_config['sort_method']);
$sort_order = request_var('sort_order', $album_config['sort_order']);

switch ($sort_method)
{
  case 'pic_time':
      $sort_method = 'pic_time';
      break;
  case 'pic_title':
      $sort_method = 'pic_title';
      break;
  case 'username':
      $sort_method = 'username';
      break;
  case 'pic_view_count':
      $sort_method = 'pic_view_count';
      break;
  case 'rating':
      $sort_method = 'rating';
      break;
  case 'comments':
      $sort_method = 'comments';
      break;
  case 'new_comment':
      $sort_method = 'new_comment';
      break;
  default:
      $sort_method = $album_config['sort_method'];
}

switch ($sort_order)
{
  case 'ASC':
    $sort_order = 'ASC';
    break;
  case 'DESC':
    $sort_order = 'DESC';
    break;
  default:
    $sort_order = $album_config['sort_order'];
}

$pics_per_page = $album_config['rows_per_page'] * $album_config['cols_per_page'];

$tot_unapproved = 0;
    
if ($total_pics > 0)
{
  $limit_sql = ($start == 0) ? $pics_per_page : $start .','. $pics_per_page;

  $pic_approval_sql = 'AND p.pic_approval = 1';
  if ($thiscat['cat_approval'] != ALBUM_USER)
  {
    if( ($auth->acl_get('a_')) or (($auth_data['moderator'] == 1) and ($thiscat['cat_approval'] == ALBUM_MOD)) )
    {
      $pic_approval_sql = '';
    }
  }

  $sql = "SELECT p.pic_id, p.pic_title, p.pic_desc, p.pic_user_id, p.pic_user_ip, p.pic_username, p.pic_time, p.pic_cat_id, p.pic_view_count, p.pic_lock, p.pic_approval, u.user_id , u.username, r.rate_pic_id, AVG(r.rate_point) AS rating, COUNT(DISTINCT c.comment_id) AS comments, MAX(c.comment_id) as new_comment
            FROM ". ALBUM_TABLE ." AS p
                LEFT JOIN ". USERS_TABLE ." AS u ON p.pic_user_id = u.user_id
                LEFT JOIN ". ALBUM_RATE_TABLE ." AS r ON p.pic_id = r.rate_pic_id
                LEFT JOIN ". ALBUM_COMMENT_TABLE ." AS c ON p.pic_id = c.comment_pic_id 
            WHERE p.pic_cat_id = '$cat_id' 
            GROUP BY p.pic_id
            ORDER BY $sort_method $sort_order
            LIMIT $limit_sql";
    $result = $db->sql_query($sql);

    $picrow = array();

    while( $row = $db->sql_fetchrow($result) )
    {
        $picrow[] = $row; 
    }
    
    for ($i = 0 ; $i < count($picrow); $i++ )
    {
        if ($picrow[$i]['pic_approval'] == 0 ) $tot_unapproved++ ;
    }

  $sql = "SELECT p.pic_id, p.pic_title, p.pic_desc, p.pic_user_id, p.pic_user_ip, p.pic_username, p.pic_time, p.pic_cat_id, p.pic_view_count, p.pic_lock, p.pic_approval, u.user_id, u.username, r.rate_pic_id, AVG(r.rate_point) AS rating, COUNT(DISTINCT c.comment_id) AS comments, MAX(c.comment_id) as new_comment
      FROM ". ALBUM_TABLE ." AS p
        LEFT JOIN ". USERS_TABLE ." AS u ON p.pic_user_id = u.user_id
        LEFT JOIN ". ALBUM_RATE_TABLE ." AS r ON p.pic_id = r.rate_pic_id
        LEFT JOIN ". ALBUM_COMMENT_TABLE ." AS c ON p.pic_id = c.comment_pic_id
      WHERE p.pic_cat_id = '$cat_id' $pic_approval_sql
      GROUP BY p.pic_id
      ORDER BY $sort_method $sort_order
      LIMIT $limit_sql";
  $result = $db->sql_query($sql);

  $picrow = array();

  while( $row = $db->sql_fetchrow($result) )
  {
    $picrow[] = $row;
  }


  for ($i = 0; $i < count($picrow); $i += $album_config['cols_per_page'])
  {
    $template->assign_block_vars('picrow', array());

    for ($j = $i; $j < ($i + $album_config['cols_per_page']); $j++)
    {
      if( $j >= count($picrow) )
      {
        $template->assign_block_vars('picrow.nopiccol', array()); 
        $template->assign_block_vars('picrow.picnodetail', array()); 
        continue;
      }

      if(!$picrow[$j]['rating'])
      {
        $picrow[$j]['rating'] = $user->lang['Not_rated'];
      }
      else
      {
        $picrow[$j]['rating'] = round($picrow[$j]['rating'], 2);
      }

      if ($thiscat['cat_approval'] != ALBUM_USER)
      {
        if( (!$auth->acl_get('a_')) or (($auth_data['moderator'] == 1) and ($thiscat['cat_approval'] == ALBUM_MOD)) )
        {
          $approval_mode = ($picrow[$j]['pic_approval'] == 0) ? 'approval' : 'unapproval';

          $approval_link = '<a href="'. append_sid("album_modcp.$phpEx?mode=$approval_mode&amp;pic_id=". $picrow[$j]['pic_id']) .'">';

          $approval_link .= ($picrow[$j]['pic_approval'] == 0) ? '<b>'. $user->lang['Approve'] .'</b>' : $user->lang['Unapprove'];

          $approval_link .= '</a>';
        }
      }

      $template->assign_block_vars('picrow.piccol', array(
        'U_PIC' => ($album_config['fullpic_popup']) ? append_sid("album_pic.$phpEx?pic_id=". $picrow[$j]['pic_id']) : append_sid("album_page.$phpEx?pic_id=". $picrow[$j]['pic_id']),
        'THUMBNAIL' => append_sid("album_thumbnail.$phpEx?pic_id=". $picrow[$j]['pic_id']),
        'DESC' => $picrow[$j]['pic_desc'],
        'APPROVAL' => $approval_link,
        )
      );

      if( ($picrow[$j]['user_id'] == ALBUM_GUEST) or ($picrow[$j]['username'] == '') )
      {
        $pic_poster = ($picrow[$j]['pic_username'] == '') ? $user->lang['Guest'] : $picrow[$j]['pic_username'];
      }
      else
      {
        $pic_poster = '<a href="'. append_sid("{$phpbb_root_path}memberlist.$phpEx?mode=viewprofile&amp;".'u='. $picrow[$j]['user_id']) .'">'. $picrow[$j]['username'] .'</a>';
      }

      $template->assign_block_vars('picrow.pic_detail', array(
        'TITLE' => $picrow[$j]['pic_title'],
        'POSTER' => $pic_poster,
        'TIME' => $user->format_date($picrow[$j]['pic_time']),

        'VIEW' => $picrow[$j]['pic_view_count'],

        'RATING' => ($album_config['rate'] == 1) ? ( '<a href="'. append_sid("album_rate.$phpEx?pic_id=". $picrow[$j]['pic_id']) . '">' . $user->lang['Rating'] . '</a>: ' . $picrow[$j]['rating'] . '<br />') : '',

        'COMMENTS' => ($album_config['comment'] == 1) ? ( '<a href="'. append_sid("album_comment.$phpEx?pic_id=". $picrow[$j]['pic_id']) . '">' . $user->lang['Comments'] . '</a>: ' . $picrow[$j]['comments'] . '<br />') : '',

        'EDIT' => ( ( $auth_data['edit'] and ($picrow[$j]['pic_user_id'] == $user->data['user_id']) ) or ($auth_data['moderator'] and ($thiscat['cat_edit_level'] != ALBUM_ADMIN) ) or ($user->data['user_level'] == ADMIN) ) ? '<a href="'. append_sid("album_edit.$phpEx?pic_id=". $picrow[$j]['pic_id']) . '">' . $user->lang['Edit_pic'] . '</a>' : '',

        'DELETE' => ( ( $auth_data['delete'] and ($picrow[$j]['pic_user_id'] == $user->data['user_id']) ) or ($auth_data['moderator'] and ($thiscat['cat_delete_level'] != ALBUM_ADMIN) ) or ($user->data['user_level'] == ADMIN) ) ? '<a href="'. append_sid("album_delete.$phpEx?pic_id=". $picrow[$j]['pic_id']) . '">' . $user->lang['Delete_pic'] . '</a>' : '',

        'MOVE' => ($auth_data['moderator']) ? '<a href="'. append_sid("album_modcp.$phpEx?mode=move&amp;pic_id=". $picrow[$j]['pic_id']) .'">'. $user->lang['Move'] .'</a>' : '',

        'LOCK' => ($auth_data['moderator']) ? '<a href="'. append_sid("album_modcp.$phpEx?mode=". (($picrow[$j]['pic_lock'] == 0) ? 'lock' : 'unlock') ."&amp;pic_id=". $picrow[$j]['pic_id']) .'">'. (($picrow[$j]['pic_lock'] == 0) ? $user->lang['Lock'] : $user->lang['Unlock']) .'</a>' : '',

        'IP' => ($auth->acl_get('a_')) ? $user->lang['IP'] . ': <a href="http://www.nic.com/cgi-bin/whois.cgi?query=' . decode_ip($picrow[$j]['pic_user_ip']) . '" target="_blank">' . decode_ip($picrow[$j]['pic_user_ip']) .'</a><br />' : ''
        )
      );
    }
  }

  $template->assign_vars(array(
    'PAGINATION' => generate_pagination(append_sid("album_cat.$phpEx?cat_id=$cat_id&amp;sort_method=$sort_method&amp;sort_order=$sort_order"), $total_pics, $pics_per_page, $start),
    'PAGE_NUMBER' => sprintf($user->lang['Page_of'], ( floor( $start / $pics_per_page ) + 1 ), ceil( $total_pics / $pics_per_page ))
    )
  );
}
else
{
  $template->assign_block_vars('no_pics', array());
}
//
// END thumbnails table
//


// ------------------------------------
// Build Jumpbox - based on $catrows which was created at the top of this file
// ------------------------------------
$album_jumpbox = '<form name="jumpbox" action="'. append_sid("album_cat.$phpEx") .'" method="get">';
$album_jumpbox .= $user->lang['Jump_to'] . ':&nbsp;<select name="cat_id" onChange="forms[\'jumpbox\'].submit()">';
for ($i = 0; $i < count($catrows); $i++)
{
  $album_jumpbox .= '<option value="'. $catrows[$i]['cat_id'] .'"';
  $album_jumpbox .= ($catrows[$i]['cat_id'] == $cat_id) ? 'selected="selected"' : '';
  $album_jumpbox .= '>' . $catrows[$i]['cat_title'] .'</option>';
}
$album_jumpbox .= '</select>';
$album_jumpbox .= '&nbsp;<input type="submit" class="liteoption" value="'. $user->lang['Go'] .'" />';
$album_jumpbox .= '<input type="hidden" name="sid" value="'. $user->data['session_id'] .'" />';
$album_jumpbox .= '</form>';
//
// END build jumpbox
//


// ------------------------------------
// additional sorting options
// ------------------------------------

$sort_rating_option = '';
$sort_comments_option = '';
if( $album_config['rate'] == 1 )
{
  $sort_rating_option = '<option value="rating" ';
  $sort_rating_option .= ($sort_method == 'rating') ? 'selected="selected"' : '';
  $sort_rating_option .= '>' . $user->lang['Rating'] .'</option>';
}
if( $album_config['comment'] == 1 )
{
  $sort_comments_option = '<option value="comments" ';
  $sort_comments_option .= ($sort_method == 'comments') ? 'selected="selected"' : '';
  $sort_comments_option .= '>' . $user->lang['Comments'] .'</option>';

  $sort_new_comment_option = '<option value="new_comment" ';
  $sort_new_comment_option .= ($sort_method == 'new_comment') ? 'selected="selected"' : '';
  $sort_new_comment_option .= '>' . $user->lang['New_Comment'] .'</option>';
}

//
// Start output of page
//
$template->assign_vars(array(
  'U_VIEW_CAT' => append_sid("album_cat.$phpEx?cat_id=$cat_id"),
  'CAT_TITLE' => $thiscat['cat_title'],

  'L_MODERATORS' => $user->lang['Moderators'],
  'MODERATORS' => $moderators_list,

  'U_UPLOAD_PIC' => append_sid("album_upload.$phpEx?cat_id=$cat_id"),
  'UPLOAD_PIC_IMG' => str_replace('%2F', '/', $user->img('button_album_upload', 'Upload_Pic')),

  'L_CATEGORY' => $user->lang['Category'],

  'L_NO_PICS' => $user->lang['No_Pics'],
  'WAITING' => ($tot_unapproved == 0) ? "" : $tot_unapproved . $user->lang['Waiting'],

  'S_COLS' => $album_config['cols_per_page'],
  'S_COL_WIDTH' => (100/$album_config['cols_per_page']) . '%',

  'L_VIEW' => $user->lang['View'],
  'L_POSTER' => $user->lang['Poster'],
  'L_POSTED' => $user->lang['POSTED'],

  'ALBUM_JUMPBOX' => $album_jumpbox,

  'S_ALBUM_ACTION' => append_sid("album_cat.$phpEx?cat_id=$cat_id"),

  'TARGET_BLANK' => ($album_config['fullpic_popup']) ? 'target="_blank"' : '',

  'L_SELECT_SORT_METHOD' => $user->lang['Select_sort_method'],
  'L_ORDER' => $user->lang['Order'],
  'L_SORT' => $user->lang['Sort'],

  'L_TIME' => $user->lang['Time'],
  'L_PIC_TITLE' => $user->lang['Pic_Title'],
  'L_USERNAME' => $user->lang['Sort_Username'],

  'SORT_TIME' => ($sort_method == 'pic_time') ? 'selected="selected"' : '',
  'SORT_PIC_TITLE' => ($sort_method == 'pic_title') ? 'selected="selected"' : '',
  'SORT_USERNAME' => ($sort_method == 'username') ? 'selected="selected"' : '',
  'SORT_VIEW' => ($sort_method == 'pic_view_count') ? 'selected="selected"' : '',

  'SORT_RATING_OPTION' => $sort_rating_option,
  'SORT_COMMENTS_OPTION' => $sort_comments_option,
  'SORT_NEW_COMMENT_OPTION' => $sort_new_comment_option,

  'L_ASC' => $user->lang['Sort_Ascending'],
  'L_DESC' => $user->lang['Sort_Descending'],

  'SORT_ASC' => ($sort_order == 'ASC') ? 'selected="selected"' : '',
  'SORT_DESC' => ($sort_order == 'DESC') ? 'selected="selected"' : '',

  'S_AUTH_LIST' => $auth_list)
);

//
// Generate the page
//
page_header($user->lang['Photo_Album']);

$template->set_filenames(array(
  'body' => 'album/album_cat_body.html')
);

page_footer();

// +------------------------------------------------------+
// |  Powered by Photo Album 2.x.x (c) 2002-2003 Smartor  |
// +------------------------------------------------------+

?>
