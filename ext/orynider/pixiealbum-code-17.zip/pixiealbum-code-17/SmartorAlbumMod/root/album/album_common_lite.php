<?php
/***************************************************************************
 *                 album_common_lite.php
 *                            -------------------
 *   begin                : Saturday, March 03, 2009
 *   copyright            : (C) 2003 Smartor
 *   email                : nuffmon@hotmail.com
 *
 *   $Id: album_common.php,v 1.0.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

if ( !defined('IN_PHPBB') )
{
  exit;
}

// Set Album root path
$album_root_path = $phpbb_root_path . 'album/';

// Include album constants
@include($album_root_path . 'album_constants.' . $phpEx);

// Include some language variables
$user->add_lang('mods/album_lite');

?>
