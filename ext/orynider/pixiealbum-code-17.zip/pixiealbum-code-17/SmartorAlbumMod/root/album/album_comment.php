<?php
/***************************************************************************
 *                             album_comment.php
 *                            -------------------
 *   begin                : Wednesday, February 05, 2003
 *   copyright            : (C) 2003 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_comment.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
include($phpbb_root_path . 'includes/functions_convert.' . $phpEx);
include($phpbb_root_path . 'includes/message_parser.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/album');

$album_root_path = $phpbb_root_path . 'album/';
include($album_root_path . 'album_constants.' . $phpEx);
include($album_root_path . 'album_common.'.$phpEx);

// Add album to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Photo_Album'],
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album.$phpEx"))
);

// ------------------------------------
// Check feature enabled
// ------------------------------------

if( $album_config['comment'] == 0 )
{
    trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
}



// ------------------------------------
// Check the request
// ------------------------------------

if( isset($_REQUEST['pic_id']) )
{
	$pic_id = request_var('pic_id', 0);
}
else
{
    if( isset($_REQUEST['comment_id']) )
	{
		$comment_id = request_var('comment_id', 0);
	}
	else
    {
        trigger_error('Bad request', E_USER_ERROR);
    }
}

// ------------------------------------
// Get $pic_id from $comment_id
// ------------------------------------

if( isset($comment_id) )
{
    $sql = "SELECT comment_id, comment_pic_id
            FROM ". ALBUM_COMMENT_TABLE ."
            WHERE comment_id = '$comment_id'";

    $result = $db->sql_query($sql);

    $row = $db->sql_fetchrow($result);

    if( empty($row) )
    {
        trigger_error('This comment does not exist', E_USER_WARNING);
    }

    $pic_id = $row['comment_pic_id'];
}


// ------------------------------------
// Get this pic info
// ------------------------------------

$sql = "SELECT p.*, u.user_id, u.username, COUNT(c.comment_id) as comments_count
        FROM ". ALBUM_TABLE ." AS p
            LEFT JOIN ". USERS_TABLE ." AS u ON p.pic_user_id = u.user_id
            LEFT JOIN ". ALBUM_COMMENT_TABLE ." AS c ON p.pic_id = c.comment_pic_id
        WHERE pic_id = '$pic_id'
        GROUP BY p.pic_id
        LIMIT 1";
$result = $db->sql_query($sql);

$thispic = $db->sql_fetchrow($result);

$cat_id = $thispic['pic_cat_id'];
$user_id = $thispic['pic_user_id'];

$total_comments = $thispic['comments_count'];
$comments_per_page = $config['posts_per_page'];

if( empty($thispic) )
{
    trigger_error($user->lang['Pic_not_exist'] . ' -> ' . $pic_id, E_USER_WARNING);
}


// ------------------------------------
// Get the current Category Info
// ------------------------------------

if ($cat_id != PERSONAL_GALLERY)
{
    $sql = "SELECT *
            FROM ". ALBUM_CAT_TABLE ."
            WHERE cat_id = '$cat_id'";
    $result = $db->sql_query($sql);

    $thiscat = $db->sql_fetchrow($result);
}
else
{
    $thiscat = init_personal_gallery_cat($user_id);
}

if (empty($thiscat))
{
    trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
}

//Add category to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $thiscat['cat_title'],
  'U_VIEW_FORUM'  => append_sid("album_cat.$phpEx?cat_id=$cat_id"))
);

// ------------------------------------
// Check the permissions
// ------------------------------------

$auth_data = album_user_access($cat_id, $thiscat, 1, 0, 0, 1, 1, 1);

if ($auth_data['view'] == 0)
{
    if (!$user->data['is_registered'])
    {
        redirect(append_sid("login.$phpEx?redirect=album_comment.$phpEx&pic_id=$pic_id"));
        exit;
    }
    else
    {
        trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
    }
}



/*
+----------------------------------------------------------
| Main work here...
+----------------------------------------------------------
*/


if( !isset($_POST['comment']) )
{
    /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
               Comments Screen
       ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


    // ------------------------------------
    // Get the comments thread
    // Beware: when this script was called with comment_id (without start)
    // ------------------------------------

    if( !isset($comment_id) )
    {
        $start = request_var('start', 0);
    }
    else
    {
        // We must do a query to co-ordinate this comment
        $sql = "SELECT COUNT(comment_id) AS count
                FROM ". ALBUM_COMMENT_TABLE ."
                WHERE comment_pic_id = $pic_id
                    AND comment_id < $comment_id";

        $result = $db->sql_query($sql);

        $row = $db->sql_fetchrow($result);

        if( !empty($row) )
        {
            $start = floor( $row['count'] / $comments_per_page ) * $comments_per_page;
        }
        else
        {
            $start = 0;
        }
    }

    if( isset($_REQUEST['sort_order']) )
    {
        switch (request_var('sort_order', 'DESC'))
        {
            case 'ASC':
                $sort_order = 'ASC';
                break;
            default:
                $sort_order = 'DESC';
        }
    }
    else
    {
        $sort_order = 'ASC';
    }

    if ($total_comments > 0)
    {
        $limit_sql = ($start == 0) ? '0,' . $comments_per_page : $start .','. $comments_per_page;

        $sql = "SELECT c.*, u.user_id, u.username
                FROM ". ALBUM_COMMENT_TABLE ." AS c
                    LEFT JOIN ". USERS_TABLE ." AS u ON c.comment_user_id = u.user_id
                WHERE c.comment_pic_id = '$pic_id'
                ORDER BY c.comment_id $sort_order
                LIMIT $limit_sql";

        $result = $db->sql_query($sql);

        $commentrow = array();

        while( $row = $db->sql_fetchrow($result) )
        {
            $commentrow[] = $row;
        }

        for ($i = 0; $i < count($commentrow); $i++)
        {
            if( ($commentrow[$i]['user_id'] == ALBUM_GUEST) or ($commentrow[$i]['username'] == '') )
            {
                $poster = ($commentrow[$i]['comment_username'] == '') ? $user->lang['Guest'] : $commentrow[$i]['comment_username'];
            }
            else
            {
                $poster = '<a href="'. append_sid("profile.$phpEx?mode=viewprofile&amp;". POST_USERS_URL .'='. $commentrow[$i]['user_id']) .'">'. $commentrow[$i]['username'] .'</a>';
            }

            if ($commentrow[$i]['comment_edit_count'] > 0)
            {
                $sql = "SELECT c.comment_id, c.comment_edit_user_id, u.user_id, u.username
                        FROM ". ALBUM_COMMENT_TABLE ." AS c
                            LEFT JOIN ". USERS_TABLE ." AS u ON c.comment_edit_user_id = u.user_id
                        WHERE c.comment_id = '".$commentrow[$i]['comment_id']."'
                        LIMIT 1";

                $result = $db->sql_query($sql);

                $lastedit_row = $db->sql_fetchrow($result);

                $edit_info = ($commentrow[$i]['comment_edit_count'] == 1) ? $user->lang['Edited_time_total'] : $user->lang['Edited_times_total'];

                $edit_info = '<br /><br />&raquo;&nbsp;'. sprintf($edit_info, $lastedit_row['username'], $user->format_date($commentrow[$i]['comment_edit_time']), $commentrow[$i]['comment_edit_count']) .'<br />';
            }
            else
            {
                $edit_info = '';
            }

            $message_parser = new parse_message($commentrow[$i]['comment_text']);
            $message_parser->magic_url(false);
            $message_parser->smilies(0);
            $commentrow[$i]['comment_text'] = (string) $message_parser->message;
            $commentrow[$i]['comment_text'] = str_replace('{SMILIES_PATH}', '../images/smilies', $commentrow[$i]['comment_text']);

            $template->assign_block_vars('commentrow', array(
                'ID' => $commentrow[$i]['comment_id'],
                'POSTER' => $poster,
                'TIME' => $user->format_date($commentrow[$i]['comment_time']),
                'IP' => ($auth->acl_get('a_')) ? '-----------------------------------<br />' . $user->lang['IP'] . ': <a href="http://www.nic.com/cgi-bin/whois.cgi?query=' . decode_ip($commentrow[$i]['comment_user_ip']) . '" target="_blank">' . decode_ip($commentrow[$i]['comment_user_ip']) .'</a><br />' : '',

                'TEXT' => nl2br($commentrow[$i]['comment_text']),
                'EDIT_INFO' => $edit_info,

                'EDIT' => ( ( $auth_data['edit'] and ($commentrow[$i]['comment_user_id'] == $user->data['user_id']) ) or ($auth_data['moderator'] and ($thiscat['cat_edit_level'] != ALBUM_ADMIN) ) or ($auth->acl_get('a_')) ) ? '<a href="'. append_sid("album_comment_edit.$phpEx?comment_id=". $commentrow[$i]['comment_id']) .'">'. $user->lang['Edit_pic'] .'</a>' : '',

                'DELETE' => ( ( $auth_data['delete'] and ($commentrow[$i]['comment_user_id'] == $user->data['user_id']) ) or ($auth_data['moderator'] and ($thiscat['cat_delete_level'] != ALBUM_ADMIN) ) or ($auth->acl_get('a_')) ) ? '<a href="'. append_sid("album_comment_delete.$phpEx?comment_id=". $commentrow[$i]['comment_id']) .'">'. $user->lang['Delete_pic'] .'</a>' : ''
                )
            );
        }

        $template->assign_block_vars('switch_comment', array());

        $template->assign_vars(array(
            'PAGINATION' => generate_pagination(append_sid("album_comment.$phpEx?pic_id=$pic_id&amp;sort_order=$sort_order"), $total_comments, $comments_per_page, $start),
            'PAGE_NUMBER' => sprintf($user->lang['Page_of'], ( floor( $start / $comments_per_page ) + 1 ), ceil( $total_comments / $comments_per_page ))
            )
        );
    }

    //
    // Start output of page
    //
    if( ($thispic['pic_user_id'] == ALBUM_GUEST) or ($thispic['username'] == '') )
    {
        $poster = ($thispic['pic_username'] == '') ? $user->lang['Guest'] : $thispic['pic_username'];
    }
    else
    {
        $poster = '<a href="'. append_sid("profile.$phpEx?mode=viewprofile&amp;". POST_USERS_URL .'='. $thispic['user_id']) .'">'. $thispic['username'] .'</a>';
    }

    //---------------------------------
    // Comment Posting Form
    //---------------------------------
    if ($auth_data['comment'] == 1)
    {
        $template->assign_block_vars('switch_comment_post', array());

        if( !$user->data['is_registered'] )
        {
            $template->assign_block_vars('switch_comment_post.logout', array());
        }
    }

    $template->assign_vars(array(
        'CAT_TITLE' => $thiscat['cat_title'],
        'U_VIEW_CAT' => ($cat_id != PERSONAL_GALLERY) ? append_sid("album_cat.$phpEx?cat_id=$cat_id") : append_sid("album_personal.$phpEx?user_id=$user_id"),

        'U_THUMBNAIL' => append_sid("album_thumbnail.$phpEx?pic_id=$pic_id"),
        'U_PIC' => ($album_config['fullpic_popup']) ? append_sid("album_pic.$phpEx?pic_id=$pic_id") : append_sid("album_page.$phpEx?pic_id=$pic_id"),

        'PIC_TITLE' => $thispic['pic_title'],
        'PIC_DESC' => nl2br($thispic['pic_desc']),

        'POSTER' => $poster,

        'PIC_TIME' => $user->format_date($thispic['pic_time']),
        'PIC_VIEW' => $thispic['pic_view_count'],
        'PIC_COMMENTS' => $total_comments,

        'TARGET_BLANK' => ($album_config['fullpic_popup']) ? 'target="_blank"' : '',

        'L_PIC_TITLE' => $user->lang['Pic_Title'],
        'L_PIC_DESC' => $user->lang['Pic_Desc'],
        'L_POSTER' => $user->lang['Poster'],
        'L_POSTED' => $user->lang['Posted'],
        'L_VIEW' => $user->lang['View'],
        'L_COMMENTS' => $user->lang['Comments'],

        'L_POST_YOUR_COMMENT' => $user->lang['Post_your_comment'],
        'L_MESSAGE' => $user->lang['Message'],
        'L_USERNAME' => $user->lang['Username'],
        'L_COMMENT_NO_TEXT' => $user->lang['Comment_no_text'],
        'L_COMMENT_TOO_LONG' => $user->lang['Comment_too_long'],
        'L_MAX_LENGTH' => $user->lang['Max_length'],
        'S_MAX_LENGTH' => $album_config['desc_length'],

        'L_ORDER' => $user->lang['Order'],
        'L_SORT' => $user->lang['Sort'],
        'L_ASC' => $user->lang['Sort_Ascending'],
        'L_DESC' => $user->lang['Sort_Descending'],

        'SORT_ASC' => ($sort_order == 'ASC') ? 'selected="selected"' : '',
        'SORT_DESC' => ($sort_order == 'DESC') ? 'selected="selected"' : '',

        'L_SUBMIT' => $user->lang['Submit'],

        'S_ALBUM_ACTION' => append_sid("album_comment.$phpEx?pic_id=$pic_id")
        )
    );

    //
    // Generate the page
    //
    page_header($user->lang['Photo_Album']);

    $template->set_filenames(array(
        'body' => 'album/album_comment_body.html')
    );

    page_footer();
}
else
{
    /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
              Comment Submited
       ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

    // ------------------------------------
    // Check the permissions: COMMENT
    // ------------------------------------

    if ($auth_data['comment'] == 0)
    {
        if (!$user->data['is_registered'])
        {
            redirect(append_sid("login.$phpEx?redirect=album_comment.$phpEx&pic_id=$pic_id"));
        }
        else
        {
            trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
        }
    }

    $comment_text = str_replace("\'", "''", htmlspecialchars(substr(trim(request_var('comment', '')), 0, $album_config['desc_length'])));

    $comment_username = (!$user->data['is_registered']) ? str_replace("\'", "''", substr(htmlspecialchars(trim(request_var('comment_username', ''))), 0, 32)) : str_replace("'", "''", htmlspecialchars(trim($user->data['username'])));

    if( empty($comment_text) )
    {
        trigger_error($user->lang['Comment_no_text'], E_USER_WARNING);
    }


    // --------------------------------
    // Check Pic Locked
    // --------------------------------

    if( ($thispic['pic_lock'] == 1) and (!$auth_data['moderator']) )
    {
        trigger_error($user->lang['Pic_Locked'], E_USER_WARNING);
    }


    // --------------------------------
    // Check username for guest posting
    // --------------------------------

    if (!$user->data['is_registered'])
    {
        if ($comment_username != '')
        {
            $result = validate_username($comment_username);
            if ( $result['error'] )
            {
                trigger_error($result['error_msg'], E_USER_ERROR);
            }
        }
    }


    // --------------------------------
    // Prepare variables
    // --------------------------------

    $comment_time = time();
    $comment_user_id = $user->data['user_id'];
    $comment_user_ip = $user->data['session_ip'];


    // --------------------------------
    // Get $comment_id
    // --------------------------------
    $sql = "SELECT MAX(comment_id) AS max
            FROM ". ALBUM_COMMENT_TABLE;

    $result = $db->sql_query($sql);

    $row = $db->sql_fetchrow($result);

    $comment_id = $row['max'] + 1;


    // --------------------------------
    // Insert into DB
    // --------------------------------
    // Note: phpBB is now returning normal dot ip
    // to keep code we will let MYSQL do the work
    // inet_ntoa(conv('7F000001',16,10))
    // conv(inet_aton('127.0.0.1'),10,16)
    
    $sql = "INSERT INTO ". ALBUM_COMMENT_TABLE ." (comment_id, comment_pic_id, comment_user_id, comment_username, comment_user_ip, comment_time, comment_text)
            VALUES ('$comment_id', '$pic_id', '$comment_user_id', '$comment_username', conv(inet_aton('$comment_user_ip'),10,16), '$comment_time', '$comment_text')";
    $result = $db->sql_query($sql);


    // --------------------------------
    // Complete... now send a message to user
    // --------------------------------

    $template->assign_vars(array(
        'META' => '<meta http-equiv="refresh" content="3;url=' . append_sid("album_comment.$phpEx?comment_id=$comment_id") . '#'.$comment_id.'">')
    );

    $message = $user->lang['Stored'] . "<br /><br />" . sprintf($user->lang['Click_view_message'], "<a href=\"" . append_sid("album_comment.$phpEx?comment_id=$comment_id") . "#$comment_id\">", "</a>") . "<br /><br />" . sprintf($user->lang['Click_return_album_index'], "<a href=\"" . append_sid("album.$phpEx") . "\">", "</a>");

    trigger_error($message, E_USER_NOTICE);
}


// +------------------------------------------------------+
// |  Powered by Photo Album 2.x.x (c) 2002-2003 Smartor  |
// +------------------------------------------------------+

?>
