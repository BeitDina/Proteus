<?php
/***************************************************************************
 *                         album_personal_index.php
 *                            -------------------
 *   begin                : Monday, February 24, 2003
 *   copyright            : (C) 2003 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_personal_index.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/album');

$album_root_path = $phpbb_root_path . 'album/';
include($album_root_path . 'album_constants.' . $phpEx);
include($album_root_path . 'album_common.'.$phpEx);

// Add album to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Photo_Album'],
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album.$phpEx"))
);

// Add personal album index to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Users_Personal_Galleries'],
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album_personal_index.$phpEx"))
);

// ------------------------------------
// Check the request
// ------------------------------------

$start = request_var('start', 0);

if ( isset($_REQUEST['mode']) )
{
    $mode = request_var('mode', '');
}
else
{
    $mode = 'joined';
}

if(isset($_REQUEST['order']))
{
    $sort_order = (request_var('order', 'ASC') == 'ASC') ? 'ASC' : 'DESC';
}
else
{
    $sort_order = 'ASC';
}

//
// Memberlist sorting
//
$mode_types_text = array($user->lang['Sort_Joined'], $user->lang['Sort_Username'], $user->lang['Pics'], $user->lang['Last_Pic']);
$mode_types = array('joindate', 'username', 'pics', 'last_pic');

$select_sort_mode = '<select name="mode">';
for($i = 0; $i < count($mode_types_text); $i++)
{
    $selected = ( $mode == $mode_types[$i] ) ? ' selected="selected"' : '';
    $select_sort_mode .= '<option value="' . $mode_types[$i] . '"' . $selected . '>' . $mode_types_text[$i] . '</option>';
}
$select_sort_mode .= '</select>';

$select_sort_order = '<select name="order">';
if($sort_order == 'ASC')
{
    $select_sort_order .= '<option value="ASC" selected="selected">' . $user->lang['Sort_Ascending'] . '</option><option value="DESC">' . $user->lang['Sort_Descending'] . '</option>';
}
else
{
    $select_sort_order .= '<option value="ASC">' . $user->lang['Sort_Ascending'] . '</option><option value="DESC" selected="selected">' . $user->lang['Sort_Descending'] . '</option>';
}
$select_sort_order .= '</select>';


/*
+----------------------------------------------------------
| Start output the page
+----------------------------------------------------------
*/

$template->assign_vars(array(
    'L_SELECT_SORT_METHOD' => $user->lang['Select_sort_method'],
    'L_ORDER' => $user->lang['Order'],
    'L_SORT' => $user->lang['Sort'],
      'L_LAST_PIC_DATE' => $user->lang['Last_Pic'],
    'L_JOINED' => $user->lang['Joined'],
    'L_PICS' => $user->lang['Pics'],
    'L_USERS_PERSONAL_GALLERIES' => $user->lang['Users_Personal_Galleries'],
    'S_MODE_SELECT' => $select_sort_mode,
    'S_ORDER_SELECT' => $select_sort_order,
    'S_MODE_ACTION' => append_sid("album_personal_index.$phpEx")
    )
);


switch( $mode )
{
    case 'joined':
        $order_by = "user_regdate ASC LIMIT $start, " . $config['topics_per_page'];
        break;
    case 'username':
        $order_by = "username $sort_order LIMIT $start, " . $config['topics_per_page'];
        break;
    case 'pics':
        $order_by = "pics $sort_order LIMIT $start, " . $config['topics_per_page'];
        break;
    case 'last_pic':
        $order_by = "last_pic $sort_order LIMIT $start, " . $config['topics_per_page'];
        break;
    default:
        $order_by = "user_regdate $sort_order LIMIT $start, " . $config['topics_per_page'];
        break;
}

$sql = "SELECT u.username, u.user_id, u.user_regdate, MAX(p.pic_id) as pic_id, p.pic_title, p.pic_user_id, COUNT(p.pic_id) AS pics, MAX(p.pic_time) as pic_time 
      FROM ". USERS_TABLE ." AS u, ". ALBUM_TABLE ." as p 
      WHERE u.user_id <> ". ANONYMOUS ." 
         AND u.user_id = p.pic_user_id 
         AND p.pic_cat_id = ". PERSONAL_GALLERY ." 
      GROUP BY user_id 
      ORDER BY $order_by"; 

$result = $db->sql_query($sql);

$memberrow = array(); 

while( $row = $db->sql_fetchrow($result) ) 
{ 
   $memberrow[] = $row; 
} 


for ($i = 0; $i < count($memberrow); $i++) 
{ 

   $pic_number = $memberrow[$i]['pics'];

   $pic_id = $memberrow[$i]['pic_id'];
$sql = "SELECT * 
         FROM ". ALBUM_TABLE ." 
         WHERE pic_id = '$pic_id'"; 
   $result = $db->sql_query($sql);

   $thispic = $db->sql_fetchrow($result); 

   $pic_title = $thispic['pic_title']; 

   if( !isset($album_config['last_pic_title_length']) ) 
   { 
      $album_config['last_pic_title_length'] = 50; 
   } 
   $pic_title_full = $pic_title; 
   if (strlen($pic_title) > $album_config['last_pic_title_length']) 
   { 
      $pic_title = substr($pic_title, 0, $album_config['last_pic_title_length']) . '...'; 
   } 

   $last_pic_info = '<br />'. $user->lang['Pic_Title'] .': <a href="';

   $last_pic_info .= ($album_config['fullpic_popup']) ? append_sid("album_pic.$phpEx?pic_id=". $pic_id) .'" title="' . $pic_title_full . '" target="_blank">' : append_sid("album_page.$phpEx?pic_id=". $pic_id) .'" title="' . $pic_title_full . '">' ; 

   $last_pic_info .= $pic_title .'</a>';

   $template->assign_block_vars('memberrow', array( 
      //'ROW_CLASS' => ( !($i % 2) ) ? $theme['td_class1'] : $theme['td_class2'], 
      'USERNAME' => $memberrow[$i]['username'], 
      'U_VIEWGALLERY' => append_sid("album_personal.$phpEx?user_id=". $memberrow[$i]['user_id']), 
      'JOINED' => $user->format_date($memberrow[$i]['user_regdate']),
      'LAST_PIC' => $user->format_date($memberrow[$i]['pic_time']) . $last_pic_info,
      'PICS' => $pic_number) 

   ); 
}

$sql = "SELECT COUNT(DISTINCT u.user_id) AS total
        FROM ". USERS_TABLE ." AS u, ". ALBUM_TABLE ." AS p
        WHERE u.user_id <> ". ANONYMOUS ."
            AND u.user_id = p.pic_user_id
            AND p.pic_cat_id = ". PERSONAL_GALLERY;

$result = $db->sql_query($sql);

if ( $total = $db->sql_fetchrow($result) )
{
    $total_galleries = $total['total'];

    $pagination = generate_pagination("album_personal_index.$phpEx?mode=$mode&amp;order=$sort_order", $total_galleries, $config['topics_per_page'], $start). '&nbsp;';
}

$template->assign_vars(array(
    'PAGINATION' => $pagination,
    'PAGE_NUMBER' => sprintf($user->lang['Page_of'], ( floor( $start / $config['topics_per_page'] ) + 1 ), ceil( $total_galleries / $config['topics_per_page'] ))
    )
);

//
// Generate the page
//
page_header($user->lang['Photo_Album']);

$template->set_filenames(array(
    'body' => 'album/album_personal_index_body.html')
);

page_footer();
// +------------------------------------------------------+
// |  Powered by Photo Album 2.x.x (c) 2002-2003 Smartor  |
// +------------------------------------------------------+

?>
