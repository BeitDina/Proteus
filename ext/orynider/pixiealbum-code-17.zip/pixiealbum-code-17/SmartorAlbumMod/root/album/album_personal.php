<?php
/***************************************************************************
 *                            album_personal.php
 *                            -------------------
 *   begin                : Wednesday, February 05, 2003
 *   copyright            : (C) 2003 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_personal.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
include($phpbb_root_path . 'includes/functions_convert.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/album');

$album_root_path = $phpbb_root_path . 'album/';
include($album_root_path . 'album_constants.' . $phpEx);
include($album_root_path . 'album_common.'.$phpEx);

// Add album to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Photo_Album'],
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album.$phpEx"))
);

// ------------------------------------
// Check the request
// ------------------------------------
if( isset($_REQUEST['user_id']) )
{
    $user_id = request_var('user_id', 0);
}
else
{
    $user_id = $user->data['user_id'];
}
//
// END check request
//


// ------------------------------------
// Check $user_id
// ------------------------------------

if( ($user_id < 1) and (!$user->data['is_registered']) )
{
    redirect(append_sid("login.$phpEx?redirect=album_personal.$phpEx"));
}


// ------------------------------------
// Get the username of this gallery's owner
// ------------------------------------

$sql = "SELECT username
        FROM ". USERS_TABLE ."
        WHERE user_id = $user_id";

$result = $db->sql_query($sql);

$row = $db->sql_fetchrow($result);

$username = $row['username'];

if( empty($username) )
{
    trigger_error('Sorry, this user does not exist', E_USER_ERROR);
}

// Add personal album user to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Personal_Gallery_Of_User'] . $username,
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album_personal.$phpEx&amp;user_id=$user_id"))
);

// ------------------------------------
// Check Permissions
// ------------------------------------
$personal_gallery_access = personal_gallery_access(1,1);

if( $personal_gallery_access['view'] == 0 )
{
    if (!$user->data['is_registered'])
    {
        redirect(append_sid("login.$phpEx?redirect=album_personal.$phpEx&amp;user_id=$user_id"));
    }
    else
    {
        trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
    }
}
//
// END check permissions
//


// ------------------------------------
// Check own gallery
// ------------------------------------

if ($user_id == $user->data['user_id'])
{
    if( $personal_gallery_access['upload'] == 0 )
    {
        trigger_error($user->lang['Not_allowed_to_create_personal_gallery'], E_USER_WARNING);
    }
}

//
// End check own gallery
//


// ------------------------------------
// Build the thumbnail page
// ------------------------------------

$start = request_var('start', 0);

if( isset($_REQUEST['sort_method']) )
{
    switch (request_var('sort_method', $album_config['sort_method']))
    {
        case 'pic_title':
            $sort_method = 'pic_title';
            break;
        case 'pic_view_count':
            $sort_method = 'pic_view_count';
            break;
        case 'rating':
            $sort_method = 'rating';
            break;
        case 'comments':
            $sort_method = 'comments';
            break;
        case 'new_comment':
            $sort_method = 'new_comment';
            break;
        default:
            $sort_method = $album_config['sort_method'];
    }
}
else
{
    $sort_method = $album_config['sort_method'];
}

if( isset($_REQUEST['sort_order']) )
{
    switch (request_var('sort_order', $album_config['sort_order']))
    {
        case 'ASC':
            $sort_order = 'ASC';
            break;
        case 'DESC':
            $sort_order = 'DESC';
            break;
        default:
            $sort_order = $album_config['sort_order'];
    }
}
else
{
    $sort_order = $album_config['sort_order'];
}

$pics_per_page = $album_config['rows_per_page'] * $album_config['cols_per_page'];


// ------------------------------------
// Count Pics
// ------------------------------------

$sql = "SELECT COUNT(pic_id) AS count
        FROM ". ALBUM_TABLE ."
        WHERE pic_cat_id = ". PERSONAL_GALLERY ."
            AND pic_user_id = $user_id";
$result = $db->sql_query($sql);

$row = $db->sql_fetchrow($result);

$total_pics = $row['count'];


// ------------------------------------
// Build up
// ------------------------------------

if ($total_pics > 0)
{
    $limit_sql = ($start == 0) ? $pics_per_page : $start .','. $pics_per_page;

    $sql = "SELECT p.pic_id, p.pic_title, p.pic_desc, p.pic_user_id, p.pic_user_ip, p.pic_time, p.pic_view_count, p.pic_lock, r.rate_pic_id, AVG(r.rate_point) AS rating, COUNT(DISTINCT c.comment_id) AS comments, MAX(c.comment_id) as new_comment
            FROM ". ALBUM_TABLE ." AS p
                LEFT JOIN ". ALBUM_RATE_TABLE ." AS r ON p.pic_id = r.rate_pic_id
                LEFT JOIN ". ALBUM_COMMENT_TABLE ." AS c ON p.pic_id = c.comment_pic_id
            WHERE p.pic_cat_id = ". PERSONAL_GALLERY ."
                AND p.pic_user_id = $user_id
            GROUP BY p.pic_id
            ORDER BY $sort_method $sort_order
            LIMIT $limit_sql";
    $result = $db->sql_query($sql);

    $picrow = array();

    while( $row = $db->sql_fetchrow($result) )
    {
        $picrow[] = $row;
    }


    // --------------------------------
    // Thumbnails table
    // --------------------------------

    for ($i = 0; $i < count($picrow); $i += $album_config['cols_per_page'])
    {
        $template->assign_block_vars('picrow', array());

        for ($j = $i; $j < ($i + $album_config['cols_per_page']); $j++)
        {
            if( $j >= count($picrow) )
            {
                $template->assign_block_vars('picrow.nopiccol', array()); 
                $template->assign_block_vars('picrow.picnodetail', array()); 
                continue;
            }

            if(!$picrow[$j]['rating'])
            {
                $picrow[$j]['rating'] = $user->lang['Not_rated'];
            }
            else
            {
                $picrow[$j]['rating'] = round($picrow[$j]['rating'], 2);
            }

            $template->assign_block_vars('picrow.piccol', array(
                'U_PIC' => ($album_config['fullpic_popup']) ? append_sid("album_pic.$phpEx?pic_id=". $picrow[$j]['pic_id']) : append_sid("album_page.$phpEx?pic_id=". $picrow[$j]['pic_id']),
                'THUMBNAIL' => append_sid("album_thumbnail.$phpEx?pic_id=". $picrow[$j]['pic_id']),
                'DESC' => $picrow[$j]['pic_desc']
                )
            );

            $template->assign_block_vars('picrow.pic_detail', array(
                'TITLE' => $picrow[$j]['pic_title'],
                'TIME' => $user->format_date($picrow[$j]['pic_time']),

                'VIEW' => $picrow[$j]['pic_view_count'],

                'RATING' => ($album_config['rate'] == 1) ? ( '<a href="'. append_sid("album_rate.$phpEx?pic_id=". $picrow[$j]['pic_id']) . '">' . $user->lang['Rating'] . '</a>: ' . $picrow[$j]['rating'] . '<br />') : '',

                'COMMENTS' => ($album_config['comment'] == 1) ? ( '<a href="'. append_sid("album_comment.$phpEx?pic_id=". $picrow[$j]['pic_id']) . '">' . $user->lang['Comments'] . '</a>: ' . $picrow[$j]['comments'] . '<br />') : '',

                'EDIT' => ( ($auth->acl_get('a_')) or ($user->data['user_id'] == $picrow[$j]['pic_user_id']) ) ? '<a href="'. append_sid("album_edit.$phpEx?pic_id=". $picrow[$j]['pic_id']) . '">' . $user->lang['Edit_pic'] . '</a>' : '',

                'DELETE' => ( ($auth->acl_get('a_')) or ($user->data['user_id'] == $picrow[$j]['pic_user_id']) ) ? '<a href="'. append_sid("album_delete.$phpEx?pic_id=". $picrow[$j]['pic_id']) . '">' . $user->lang['Delete_pic'] . '</a>' : '',

                'LOCK' => ($auth->acl_get('a_')) ? '<a href="'. append_sid("album_modcp.$phpEx?mode=". (($picrow[$j]['pic_lock'] == 0) ? 'lock' : 'unlock') ."&amp;pic_id=". $picrow[$j]['pic_id']) .'">'. (($picrow[$j]['pic_lock'] == 0) ? $user->lang['Lock'] : $user->lang['Unlock']) .'</a>' : '',

                'IP' => ($auth->acl_get('a_')) ? $user->lang['IP'] . ': <a href="http://www.nic.com/cgi-bin/whois.cgi?query=' . decode_ip($picrow[$j]['pic_user_ip']) . '" target="_blank">' . decode_ip($picrow[$j]['pic_user_ip']) .'</a><br />' : ''
                )
            );
        }
    }


    // --------------------------------
    // Pagination
    // --------------------------------

    $template->assign_vars(array(
        'PAGINATION' => generate_pagination(append_sid("album_personal.$phpEx?user_id=$user_id&amp;sort_method=$sort_method&amp;sort_order=$sort_order"), $total_pics, $pics_per_page, $start),
        'PAGE_NUMBER' => sprintf($user->lang['Page_of'], ( floor( $start / $pics_per_page ) + 1 ), ceil( $total_pics / $pics_per_page ))
        )
    );
}
else
{
    $template->assign_block_vars('no_pics', array());
}


/*
+----------------------------------------------------------
| Main page...
+----------------------------------------------------------
*/

// ------------------------------------
// additional sorting options
// ------------------------------------

$sort_rating_option = '';
$sort_comments_option = '';
if( $album_config['rate'] == 1 )
{
    $sort_rating_option = '<option value="rating" ';
    $sort_rating_option .= ($sort_method == 'rating') ? 'selected="selected"' : '';
    $sort_rating_option .= '>' . $user->lang['Rating'] .'</option>';
}
if( $album_config['comment'] == 1 )
{
    $sort_comments_option = '<option value="comments" ';
    $sort_comments_option .= ($sort_method == 'comments') ? 'selected="selected"' : '';
    $sort_comments_option .= '>' . $user->lang['Comments'] .'</option>';

    $sort_new_comment_option = '<option value="new_comment" ';
    $sort_new_comment_option .= ($sort_method == 'new_comment') ? 'selected="selected"' : '';
    $sort_new_comment_option .= '>' . $user->lang['New_Comment'] .'</option>';
}


//
// Start output of page
//

if( $user_id == $user->data['user_id'] )
{
    $template->assign_block_vars('your_personal_gallery', array());
}

$template->assign_vars(array(
    'U_UPLOAD_PIC' => append_sid("album_upload.$phpEx?cat_id=$cat_id"),
    'UPLOAD_PIC_IMG' => str_replace('%2F', '/', $user->img('button_album_upload', 'Upload_Pic')),

    'L_PERSONAL_GALLERY_NOT_CREATED' => sprintf($user->lang['Personal_gallery_not_created'], $username),

    'TARGET_BLANK' => ($album_config['fullpic_popup']) ? 'target="_blank"' : '',

    'S_COLS' => $album_config['cols_per_page'],
    'S_COL_WIDTH' => (100/$album_config['cols_per_page']) . '%',

    'L_VIEW' => $user->lang['View'],
    'L_POSTED' => $user->lang['Posted'],

    'U_PERSONAL_GALLERY' => append_sid("album_personal.$phpEx?user_id=$user_id"),
    'L_YOUR_PERSONAL_GALLERY' => $user->lang['Your_Personal_Gallery'],
    'L_PERSONAL_GALLERY_EXPLAIN' => $user->lang['Personal_Gallery_Explain'],

    'L_PERSONAL_GALLERY_OF_USER' => $user->lang['Personal_Gallery_Of_User'] . $username,

    'L_SELECT_SORT_METHOD' => $user->lang['Select_sort_method'],
    'L_ORDER' => $user->lang['Order'],
    'L_SORT' => $user->lang['Sort'],

    'L_TIME' => $user->lang['Time'],
    'L_PIC_TITLE' => $user->lang['Pic_Title'],

    'SORT_TIME' => ($sort_method == 'pic_time') ? 'selected="selected"' : '',
    'SORT_PIC_TITLE' => ($sort_method == 'pic_title') ? 'selected="selected"' : '',
    'SORT_VIEW' => ($sort_method == 'pic_view_count') ? 'selected="selected"' : '',

    'SORT_RATING_OPTION' => $sort_rating_option,
    'SORT_COMMENTS_OPTION' => $sort_comments_option,
    'SORT_NEW_COMMENT_OPTION' => $sort_new_comment_option,

    'L_ASC' => $user->lang['Sort_Ascending'],
    'L_DESC' => $user->lang['Sort_Descending'],

    'SORT_ASC' => ($sort_order == 'ASC') ? 'selected="selected"' : '',
    'SORT_DESC' => ($sort_order == 'DESC') ? 'selected="selected"' : '')
);


//
// Generate the page
//
page_header($user->lang['Photo_Album']);

$template->set_filenames(array(
    'body' => 'album/album_personal_body.html')
);

page_footer();


// +------------------------------------------------------+
// |  Powered by Photo Album 2.x.x (c) 2002-2003 Smartor  |
// +------------------------------------------------------+

?>
