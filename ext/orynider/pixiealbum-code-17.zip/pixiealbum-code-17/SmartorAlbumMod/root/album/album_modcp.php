<?php
/***************************************************************************
 *                              album_modcp.php
 *                            -------------------
 *   begin                : Wednesday, February 05, 2003
 *   copyright            : (C) 2004 Smartor
 *   email                : smartor_xp@hotmail.com
 *
 *   $Id: album_modcp.php,v 2.1.0 2009/03/04 13:51:00 nuffmon Exp $
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/album');

$album_root_path = $phpbb_root_path . 'album/';
include($album_root_path . 'album_constants.' . $phpEx);
include($album_root_path . 'album_common.'.$phpEx);

// Add album to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $user->lang['Photo_Album'],
  'U_VIEW_FORUM'  => append_sid("{$album_root_path}album.$phpEx"))
);

// ------------------------------------
// Get the $pic_id from GET method then query out the category
// If $pic_id not found we will assign it to FALSE
// We will check $pic_id[] in POST method later (in $mode carry out)
// ------------------------------------
if( isset($_GET['pic_id']) )
{
    $pic_id = request_var('pic_id',0);
}
else
{
    $pic_id = FALSE;
}

if( $pic_id != FALSE )
{
    //
    // Get this pic info
    //
    $sql = "SELECT *
            FROM ". ALBUM_TABLE ."
            WHERE pic_id = '$pic_id'";
    $result = $db->sql_query($sql);
    
    $thispic = $db->sql_fetchrow($result);
    if( empty($thispic) )
    {
        message_die(GENERAL_ERROR, $user->lang['Pic_not_exist']);
    }
    $cat_id = $thispic['pic_cat_id'];
    $user_id = $thispic['pic_user_id'];
}
else
{
    //
    // No $pic_id found, try to find $cat_id
    //
    if( isset($_REQUEST['cat_id']) )
    {
        $cat_id = request_var('cat_id', 0);
    }
    else
    {
        trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
    }
}
//
// END check $pic_id and $cat_id
//


// ------------------------------------
// Get the cat info
// ------------------------------------
if( ($cat_id == PERSONAL_GALLERY) and (($_GET['mode'] == 'lock') or ($_GET['mode'] == 'unlock')) )
{
    $thiscat = init_personal_gallery_cat($user_id);
}
else
{
    $sql = "SELECT *
            FROM ". ALBUM_CAT_TABLE ."
            WHERE cat_id = '$cat_id'";
    $result = $db->sql_query($sql);

    $thiscat = $db->sql_fetchrow($result);
}

if (empty($thiscat))
{
    trigger_error($user->lang['Category_not_exist'], E_USER_WARNING);
}

$auth_data = album_user_access($cat_id, $thiscat, 0, 0, 0, 0, 0, 0); // MODERATOR only
//
// END category info
//

//Add category to navlinks
$template->assign_block_vars('navlinks', array(
  'FORUM_NAME'  => $thiscat['cat_title'],
  'U_VIEW_FORUM'  => append_sid("album_cat.$phpEx?cat_id=$cat_id"))
);

// ------------------------------------
// set $mode (select action)
// ------------------------------------
if( isset($_POST['mode']) )
{
    // Oh data from Mod CP
    if( isset($_POST['move']) )
    {
        $mode = 'move';
    }
    else if( isset($_POST['lock']) )
    {
        $mode = 'lock';
    }
    else if( isset($_POST['unlock']) )
    {
        $mode = 'unlock';
    }
    else if( isset($_POST['delete']) )
    {
        $mode = 'delete';
    }
    else if( isset($_POST['approval']) )
    {
        $mode = 'approval';
    }
    else if( isset($_POST['unapproval']) )
    {
        $mode = 'unapproval';
    }
    else
    {
        $mode = '';
    }
}
else if( isset($_GET['mode']) )
{
    $mode = trim($_GET['mode']);
}
else
{
    $mode = '';
}
//
// END $mode (select action)
//


// ------------------------------------
// Check the permissions
// ------------------------------------
if ($auth_data['moderator'] == 0)
{
    if (!$userdata['session_logged_in'])
    {
        redirect(append_sid("login.$phpEx?redirect=album_modcp.$phpEx&amp;cat_id=$cat_id"));
    }
    else
    {
        trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
    }
}
//
// END permissions
//



/*
+----------------------------------------------------------
| Main work here...
+----------------------------------------------------------
*/

if ($mode == '')
{
    // --------------------------------
    // Moderator Control Panel
    // --------------------------------

    // Set Variables
    if( isset($_GET['start']) )
    {
        $start = intval($_GET['start']);
    }
    else if( isset($_POST['start']) )
    {
        $start = intval($_POST['start']);
    }
    else
    {
        $start = 0;
    }

    if( isset($_GET['sort_method']) )
    {
        switch ($_GET['sort_method'])
        {
            case 'pic_title':
                $sort_method = 'pic_title';
                break;
            case 'pic_user_id':
                $sort_method = 'pic_user_id';
                break;
            case 'pic_view_count':
                $sort_method = 'pic_view_count';
                break;
            case 'rating':
                $sort_method = 'rating';
                break;
            case 'comments':
                $sort_method = 'comments';
                break;
            case 'new_comment':
                $sort_method = 'new_comment';
                break;
            default:
                $sort_method = 'pic_time';
        }
    }
    else if( isset($_POST['sort_method']) )
    {
        switch ($_POST['sort_method'])
        {
            case 'pic_title':
                $sort_method = 'pic_title';
                break;
            case 'pic_user_id':
                $sort_method = 'pic_user_id';
                break;
            case 'pic_view_count':
                $sort_method = 'pic_view_count';
                break;
            case 'rating':
                $sort_method = 'rating';
                break;
            case 'comments':
                $sort_method = 'comments';
                break;
            case 'new_comment':
                $sort_method = 'new_comment';
                break;
            default:
                $sort_method = 'pic_time';
        }
    }
    else
    {
        $sort_method = 'pic_time';
    }

    if( isset($_GET['sort_order']) )
    {
        switch ($_GET['sort_order'])
        {
            case 'ASC':
                $sort_order = 'ASC';
                break;
            default:
                $sort_order = 'DESC';
        }
    }
    else if( isset($_POST['sort_order']) )
    {
        switch ($_POST['sort_order'])
        {
            case 'ASC':
                $sort_order = 'ASC';
                break;
            default:
                $sort_order = 'DESC';
        }
    }
    else
    {
        $sort_order = 'DESC';
    }

    // Count Pics
    $sql = "SELECT COUNT(pic_id) AS count
            FROM ". ALBUM_TABLE ."
            WHERE pic_cat_id = '$cat_id'";
    $result = $db->sql_query($sql);

    $row = $db->sql_fetchrow($result);

    $total_pics = $row['count'];

    $pics_per_page = $config['topics_per_page']; // Text list only

    // get information from DB
    if ($total_pics > 0)
    {
        $limit_sql = ($start == 0) ? $pics_per_page : $start .', '. $pics_per_page;

        $pic_approval_sql = '';
        if( (!$auth->acl_get('a_')) and ($thiscat['cat_approval'] == ALBUM_ADMIN) )
        {
            // because he went through my Permission Checking above so he must be at least a Moderator
            $pic_approval_sql = 'AND p.pic_approval = 1';
        }

        $sql = "SELECT p.pic_id, p.pic_title, p.pic_user_id, p.pic_user_ip, p.pic_username, p.pic_time, p.pic_cat_id, p.pic_view_count, p.pic_lock, p.pic_approval, u.user_id, u.username, r.rate_pic_id, AVG(r.rate_point) AS rating, COUNT(c.comment_id) AS comments, MAX(c.comment_id) AS new_comment
                FROM ". ALBUM_TABLE ." AS p
                    LEFT JOIN ". USERS_TABLE ." AS u ON p.pic_user_id = u.user_id
                    LEFT JOIN ". ALBUM_RATE_TABLE ." AS r ON p.pic_id = r.rate_pic_id
                    LEFT JOIN ". ALBUM_COMMENT_TABLE ." AS c ON p.pic_id = c.comment_pic_id
                WHERE p.pic_cat_id = '$cat_id' $pic_approval_sql
                GROUP BY p.pic_id
                ORDER BY $sort_method $sort_order
                LIMIT $limit_sql";
        $result = $db->sql_query($sql);

        $picrow = array();

        while( $row = $db->sql_fetchrow($result) )
        {
            $picrow[] = $row;
        }

        for ($i = 0; $i <count($picrow); $i++)
        {
            if( ($picrow[$i]['user_id'] == ALBUM_GUEST) or ($picrow[$i]['username'] == '') )
            {
                $pic_poster = ($picrow[$i]['pic_username'] == '') ? $lang['Guest'] : $picrow[$i]['pic_username'];
            }
            else
            {
                $pic_poster = '<a href="'. append_sid("profile.$phpEx?mode=viewprofile&amp;". POST_USERS_URL .'='. $picrow[$i]['user_id']) .'">'. $picrow[$i]['username'] .'</a>';
            }

            $template->assign_block_vars('picrow', array(
                'PIC_ID' => $picrow[$i]['pic_id'],
                'PIC_TITLE' => '<a href="'. append_sid("album_pic.$phpEx?pic_id=". $picrow[$i]['pic_id']) .'" target="_blank">'. $picrow[$i]['pic_title'] .'</a>',
                'POSTER' => $pic_poster,
                'TIME' => $user->format_date($picrow[$i]['pic_time']),
                'RATING' => ($picrow[$i]['rating'] == 0) ? $user->lang['Not_rated'] : round($picrow[$i]['rating'], 2),
                'COMMENTS' => $picrow[$i]['comments'],
                'LOCK' => ($picrow[$i]['pic_lock'] == 0) ? '' : $user->lang['Locked'],
                'APPROVAL' => ($picrow[$i]['pic_approval'] == 0) ? $user->lang['Not_approved'] : $user->lang['Approved']
                )
            );
        }

        $template->assign_vars(array(
            'PAGINATION' => generate_pagination(append_sid("album_modcp.$phpEx?cat_id=$cat_id&amp;sort_method=$sort_method&amp;sort_order=$sort_order"), $total_pics, $pics_per_page, $start),
            'PAGE_NUMBER' => sprintf($lang['Page_of'], ( floor( $start / $pics_per_page ) + 1 ), ceil( $total_pics / $pics_per_page ))
            )
        );
    }
    else
    {
        // No Pics
        $template->assign_block_vars('no_pics', array());
    }

    //
    // Start output of page (ModCP)
    //
    $sort_rating_option = '';
    $sort_comments_option = '';
    if( $album_config['rate'] == 1 )
    {
        $sort_rating_option = '<option value="rating" ';
        $sort_rating_option .= ($sort_method == 'rating') ? 'selected="selected"' : '';
        $sort_rating_option .= '>' . $user->lang['Rating'] .'</option>';
    }
    if( $album_config['comment'] == 1 )
    {
        $sort_comments_option = '<option value="comments" ';
        $sort_comments_option .= ($sort_method == 'comments') ? 'selected="selected"' : '';
        $sort_comments_option .= '>' . $user->lang['Comments'] .'</option>';
        $sort_new_comment_option = '<option value="new_comment" ';
        $sort_new_comment_option .= ($sort_method == 'new_comment') ? 'selected="selected"' : '';
        $sort_new_comment_option .= '>' . $user->lang['New_Comment'] .'</option>';
    }

    $template->assign_vars(array(
        'U_VIEW_CAT' => append_sid("album_modcp.$phpEx?cat_id=$cat_id"),
        'CAT_TITLE' => $thiscat['cat_title'],

        'L_CATEGORY' => $user->lang['Category'],
        'L_MODCP' => $user->lang['MCP'],

        'L_NO_PICS' => $user->lang['No_Pics'],

        'L_VIEW' => $user->lang['View'],
        'L_POSTER' => $user->lang['Poster'],
        'L_POSTED' => $user->lang['Posted'],

        'S_ALBUM_ACTION' => append_sid("album_modcp.$phpEx?cat_id=$cat_id"),

        'L_SELECT_SORT_METHOD' => $user->lang['Select_sort_method'],
        'L_ORDER' => $user->lang['Order'],
        'L_SORT' => $user->lang['Sort'],

        'L_TIME' => $user->lang['Time'],
        'L_PIC_TITLE' => $user->lang['Pic_Title'],
        'L_POSTER' => $user->lang['Poster'],
        'L_RATING' => $user->lang['Rating'],
        'L_COMMENTS' => $user->lang['Comments'],
        'L_STATUS' => $user->lang['Status'],
        'L_APPROVAL' => $user->lang['Approval'],
        'L_SELECT' => $user->lang['Select'],
        'L_DELETE' => $user->lang['Delete'],
        'L_MOVE' => $user->lang['Move'],
        'L_LOCK' => $user->lang['Lock'],
        'L_UNLOCK' => $user->lang['Unlock'],

        'DELETE_BUTTON' => ($auth_data['delete'] == 1) ? '<input type="submit" class="liteoption" name="delete" value="'. $user->lang['Delete'] .'" />' : '',

        'APPROVAL_BUTTON' => ( (!$auth->acl_get('a_')) and ($thiscat['cat_approval'] == ALBUM_ADMIN) ) ? '' : '<input type="submit" class="liteoption" name="approval" value="'. $user->lang['Approve'] .'" />',

        'UNAPPROVAL_BUTTON' => ( (!$auth->acl_get('a_')) and ($thiscat['cat_approval'] == ALBUM_ADMIN) ) ? '' : '<input type="submit" class="liteoption" name="unapproval" value="'. $user->lang['Unapprove'] .'" />',

        'L_USERNAME' => $user->lang['Sort_Username'],

        'SORT_TIME' => ($sort_method == 'pic_time') ? 'selected="selected"' : '',
        'SORT_PIC_TITLE' => ($sort_method == 'pic_title') ? 'selected="selected"' : '',
        'SORT_USERNAME' => ($sort_method == 'pic_user_id') ? 'selected="selected"' : '',
        'SORT_VIEW' => ($sort_method == 'pic_view_count') ? 'selected="selected"' : '',

        'SORT_RATING_OPTION' => $sort_rating_option,
        'SORT_COMMENTS_OPTION' => $sort_comments_option,
        'SORT_NEW_COMMENT_OPTION' => $sort_new_comment_option,

        'L_ASC' => $user->lang['Sort_Ascending'],
        'L_DESC' => $user->lang['Sort_Descending'],

        'SORT_ASC' => ($sort_order == 'ASC') ? 'selected="selected"' : '',
        'SORT_DESC' => ($sort_order == 'DESC') ? 'selected="selected"' : ''
        )
    );

    //
    // Generate the page (ModCP)
    //
    page_header($user->lang['Photo_Album']);

    $template->set_filenames(array(
        'body' => 'album/album_modcp_body.html')
    );

    page_footer();
}
else
{
    //
    // Switch with $mode
    //
    if ($mode == 'move')
    {
        //-----------------------------
        // MOVE
        //-----------------------------

        if( !isset($_POST['target']) )
        {
            // if "target" has not been set, we will open the category select form
            //
            // we must check POST method now
            $pic_id_array = array();
            if ($pic_id != FALSE) // from GET
            {
                $pic_id_array[] = $pic_id;
            }
            else
            {
                // Check $pic_id[] on POST Method now
                if( isset($_POST['pic_id']) )
                {
                    $pic_id_array = $_POST['pic_id'];
                    if( !is_array($pic_id_array) )
                    {
                        trigger_error('Invalid request', E_USER_ERROR);
                    }
                }
                else
                {
                    trigger_error('No pics spicified', E_USER_ERROR);
                }
            }

            // We must send out the $pic_id_array to store data between page changing
            for ($i = 0; $i < count($pic_id_array); $i++)
            {
                $template->assign_block_vars('pic_id_array', array(
                    'VALUE' => $pic_id_array[$i])
                );
            }

            //
            // Create categories select
            //
            $sql = "SELECT *
                    FROM ". ALBUM_CAT_TABLE ."
                    WHERE cat_id <> '$cat_id'
                    ORDER BY cat_order ASC";
            $result = $db->sql_query($sql);

            $catrows = array();

            while( $row = $db->sql_fetchrow($result) )
            {
                $album_user_access = album_user_access($row['cat_id'], $row, 0, 1, 0, 0, 0, 0);

                if ($album_user_access['upload'] == 1)
                {
                    $catrows[] = $row;
                }
            }

            if( count($catrows) == 0 )
            {
                trigger_error('There is no more categories which you have permisson to move pics to', E_USER_ERROR);
            }

            // write categories out
            $category_select = '<select name="target">';

            for ($i = 0; $i < count($catrows); $i++)
            {
                $category_select .= '<option value="'. $catrows[$i]['cat_id'] .'">'. $catrows[$i]['cat_title'] .'</option>';
            }

            $category_select .= '</select>';
            // end write

            //
            // Start output of page
            //
            
            $template->assign_vars(array(
                'S_ALBUM_ACTION' => append_sid("album_modcp.$phpEx?mode=move&amp;cat_id=$cat_id"),
                'L_MOVE' => $user->lang['Move'],
                'L_MOVE_TO_CATEGORY' => $user->lang['Move_to_Category'],
                'S_CATEGORY_SELECT' => $category_select)
            );

            //
            // Generate the page
            //
            page_header($user->lang['Photo_Album']);

            $template->set_filenames(array(
                'body' => 'album/album_move_body.html')
            );

            page_footer();
        }
        else
        {
            // Do the MOVE action
            //
            // Now we only get $pic_id[] via POST (after the select target screen)
            if( isset($_POST['pic_id']) )
            {
                $pic_id = request_var('pic_id', array(0));
                if( is_array($pic_id) )
                {
                    $pic_id_sql = implode(',', $pic_id);
                }
                else
                {
                    trigger_error('Invalid request', E_USER_ERROR);
                }
            }
            else
            {
                trigger_error('No pics specified', E_USER_ERROR);
            }

            // well, we got the array of pic_id but we must do a check to make sure all these
            // pics are in this category (prevent some naughty moderators to access un-authorised pics)
            $sql = "SELECT pic_id
                    FROM ". ALBUM_TABLE ."
                    WHERE pic_id IN ($pic_id_sql) AND pic_cat_id <> $cat_id";
            $result = $db->sql_query($sql);

            if( $db->sql_numrows($result) > 0 )
            {
                trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
            }

            // Update the DB
            $sql = "UPDATE ". ALBUM_TABLE ."
                    SET pic_cat_id = ". intval($HTTP_POST_VARS['target']) ."
                    WHERE pic_id IN ($pic_id_sql)";
            $result = $db->sql_query($sql);

            $message = $user->lang['Pics_moved_successfully'] .'<br /><br />'. sprintf($user->lang['Click_return_category'], "<a href=\"" . append_sid("album_cat.$phpEx?cat_id=$cat_id") . "\">", "</a>") .'<br /><br />'. sprintf($user->lang['Click_return_modcp'], "<a href=\"" . append_sid("album_modcp.$phpEx?cat_id=$cat_id") . "\">", "</a>") . "<br /><br />" . sprintf($user->lang['Click_return_album_index'], "<a href=\"" . append_sid("album.$phpEx") . "\">", "</a>");

            trigger_error($message, E_USER_NOTICE);
        }
    }
    else if ($mode == 'lock')
    {
        //-----------------------------
        // LOCK
        //-----------------------------

        // we must check POST method now
        if ($pic_id != FALSE) // from GET
        {
            $pic_id_sql = $pic_id;
        }
        else
        {
            // Check $pic_id[] on POST Method now
            if( isset($_POST['pic_id']) )
            {
                $pic_id = request_var('pic_id', array(0));
                if( is_array($pic_id) )
                {
                    $pic_id_sql = implode(',', $pic_id);
                }
                else
                {
                    trigger_error('Invalid request', E_USER_ERROR);
                }
            }
            else
            {
                trigger_error('No pics specified', E_USER_ERROR);
            }
        }

        // well, we got the array of pic_id but we must do a check to make sure all these
        // pics are in this category (prevent some naughty moderators to access un-authorised pics)
        $sql = "SELECT COUNT(*) AS pic_count
                FROM ". ALBUM_TABLE ."
                WHERE pic_id IN ($pic_id_sql) AND pic_cat_id <> $cat_id";
        $result = $db->sql_query($sql);

        $row = $db->sql_fetchrow($result);

        if( $row['pic_count'] > 0 )
        {
            trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
        }

        // update the DB
        $sql = "UPDATE ". ALBUM_TABLE ."
                SET pic_lock = 1
                WHERE pic_id IN ($pic_id_sql)";
        $result = $db->sql_query($sql);

        $message = $user->lang['Pics_locked_successfully'] .'<br /><br />';

        if ($cat_id != PERSONAL_GALLERY)
        {
            $message .= sprintf($user->lang['Click_return_category'], "<a href=\"" . append_sid("album_cat.$phpEx?cat_id=$cat_id") . "\">", "</a>") .'<br /><br />'. sprintf($user->lang['Click_return_modcp'], "<a href=\"" . append_sid("album_modcp.$phpEx?cat_id=$cat_id") . "\">", "</a>") . "<br /><br />";
        }
        else
        {
            $message .= sprintf($user->lang['Click_return_personal_gallery'], "<a href=\"" . append_sid("album_personal.$phpEx?user_id=$user_id") . "\">", "</a>");
        }

        $message .= '<br /><br />' . sprintf($user->lang['Click_return_album_index'], "<a href=\"" . append_sid("album.$phpEx") . "\">", "</a>");

        trigger_error($message, E_USER_NOTICE);
    }
    else if ($mode == 'unlock')
    {
        //-----------------------------
        // UNLOCK
        //-----------------------------

        // we must check POST method now
        if ($pic_id != FALSE) // from GET
        {
            $pic_id_sql = $pic_id;
        }
        else
        {
            // Check $pic_id[] on POST Method now
            if( isset($_POST['pic_id']) )
            {
                $pic_id = request_var('pic_id', array(0));
                if( is_array($pic_id) )
                {
                    $pic_id_sql = implode(',', $pic_id);
                }
                else
                {
                    trigger_error('Invalid request', E_USER_ERROR);
                }
            }
            else
            {
                trigger_error('No pics specified', E_USER_ERROR);
            }
        }

        // well, we got the array of pic_id but we must do a check to make sure all these
        // pics are in this category (prevent some naughty moderators to access un-authorised pics)
        $sql = "SELECT COUNT(*) AS pic_count
                FROM ". ALBUM_TABLE ."
                WHERE pic_id IN ($pic_id_sql) AND pic_cat_id <> $cat_id";
        $result = $db->sql_query($sql);

        $row = $db->sql_fetchrow($result);

        if( $row['pic_count'] > 0 )
        {
            trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
        }

        // update the DB
        $sql = "UPDATE ". ALBUM_TABLE ."
                SET pic_lock = 0
                WHERE pic_id IN ($pic_id_sql)";
        $result = $db->sql_query($sql);

        $message = $user->lang['Pics_unlocked_successfully'] .'<br /><br />';

        if ($cat_id != PERSONAL_GALLERY)
        {
            $message .= sprintf($user->lang['Click_return_category'], "<a href=\"" . append_sid("album_cat.$phpEx?cat_id=$cat_id") . "\">", "</a>") .'<br /><br />'. sprintf($user->lang['Click_return_modcp'], "<a href=\"" . append_sid("album_modcp.$phpEx?cat_id=$cat_id") . "\">", "</a>") . "<br /><br />";
        }
        else
        {
            $message .= sprintf($user->lang['Click_return_personal_gallery'], "<a href=\"" . append_sid("album_personal.$phpEx?user_id=$user_id") . "\">", "</a>");
        }

        $message .= '<br /><br />' . sprintf($user->lang['Click_return_album_index'], "<a href=\"" . append_sid("album.$phpEx") . "\">", "</a>");

        trigger_error($message, E_USER_NOTICE);
    }
    else if ($mode == 'approval')
    {
        //-----------------------------
        // APPROVAL
        //-----------------------------

        // we must check POST method now
        if ($pic_id != FALSE) // from GET
        {
            $pic_id_sql = $pic_id;
        }
        else
        {
            // Check $pic_id[] on POST Method now
            if( isset($_POST['pic_id']) )
            {
                $pic_id = request_var('pic_id', array(0));
                if( is_array($pic_id) )
                {
                    $pic_id_sql = implode(',', $pic_id);
                }
                else
                {
                    trigger_error('Invalid request', E_USER_ERROR);
                }
            }
            else
            {
                trigger_error('No pics specified', E_USER_ERROR);
            }
        }

        // well, we got the array of pic_id but we must do a check to make sure all these
        // pics are in this category (prevent some naughty moderators to access un-authorised pics)
        $sql = "SELECT COUNT(*) AS pic_count
                FROM ". ALBUM_TABLE ."
                WHERE pic_id IN ($pic_id_sql) AND pic_cat_id <> $cat_id";
        $result = $db->sql_query($sql);

        $row = $db->sql_fetchrow($result);

        if( $row['pic_count'] > 0 )
        {
            trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
        }

        // update the DB
        $sql = "UPDATE ". ALBUM_TABLE ."
                SET pic_approval = 1
                WHERE pic_id IN ($pic_id_sql)";
        $result = $db->sql_query($sql);

        $message = $user->lang['Pics_approved_successfully'] .'<br /><br />'. sprintf($user->lang['Click_return_category'], "<a href=\"" . append_sid("album_cat.$phpEx?cat_id=$cat_id") . "\">", "</a>") .'<br /><br />'. sprintf($user->lang['Click_return_modcp'], "<a href=\"" . append_sid("album_modcp.$phpEx?cat_id=$cat_id") . "\">", "</a>") . "<br /><br />" . sprintf($user->lang['Click_return_album_index'], "<a href=\"" . append_sid("album.$phpEx") . "\">", "</a>");

        trigger_error($message, E_USER_NOTICE);
    }
    else if ($mode == 'unapproval')
    {
        //-----------------------------
        // UNAPPROVAL
        //-----------------------------

        // we must check POST method now
        if ($pic_id != FALSE) // from GET
        {
            $pic_id_sql = $pic_id;
        }
        else
        {
            // Check $pic_id[] on POST Method now
            if( isset($_POST['pic_id']) )
            {
                $pic_id = request_var('pic_id', array(0));
                if( is_array($pic_id) )
                {
                    $pic_id_sql = implode(',', $pic_id);
                }
                else
                {
                    trigger_error('Invalid request', E_USER_ERROR);
                }
            }
            else
            {
                trigger_error('No pics specified', E_USER_ERROR);
            }
        }

        // well, we got the array of pic_id but we must do a check to make sure all these
        // pics are in this category (prevent some naughty moderators to access un-authorised pics)
        $sql = "SELECT COUNT(*) AS pic_count
                FROM ". ALBUM_TABLE ."
                WHERE pic_id IN ($pic_id_sql) AND pic_cat_id <> $cat_id";
        $result = $db->sql_query($sql);

        $row = $db->sql_fetchrow($result);

        if( $row['pic_count'] > 0 )
        {
            trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
        }

        // update the DB
        $sql = "UPDATE ". ALBUM_TABLE ."
                SET pic_approval = 0
                WHERE pic_id IN ($pic_id_sql)";
        $result = $db->sql_query($sql);

        $message = $user->lang['Pics_unapproved_successfully'] .'<br /><br />'. sprintf($user->lang['Click_return_category'], "<a href=\"" . append_sid("album_cat.$phpEx?cat_id=$cat_id") . "\">", "</a>") .'<br /><br />'. sprintf($user->lang['Click_return_modcp'], "<a href=\"" . append_sid("album_modcp.$phpEx?cat_id=$cat_id") . "\">", "</a>") . "<br /><br />" . sprintf($user->lang['Click_return_album_index'], "<a href=\"" . append_sid("album.$phpEx") . "\">", "</a>");

        trigger_error($message, E_USER_NOTICE);
    }
    else if ($mode == 'delete')
    {
        //-----------------------------
        // DELETE
        //-----------------------------

        if ($auth_data['delete'] == 0)
        {
            trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
        }

        if( !isset($_POST['confirm']) )
        {
            // we must check POST method now
            $pic_id_array = array();
            if ($pic_id != FALSE) // from GET
            {
                $pic_id_array[] = $pic_id;
            }
            else
            {
                // Check $pic_id[] on POST Method now
                if( isset($_POST['pic_id']) )
                {
                    $pic_id_array = request_var('pic_id', array(0));
                    if( !is_array($pic_id_array) )
                    {
                        trigger_error('Invalid request', E_USER_ERROR);
                    }
                }
                else
                {
                    trigger_error('No pics specified', E_USER_ERROR);
                }
            }
      if ( isset($_POST['cancel']) )
         {
            $redirect = "album_modcp.$phpEx?cat_id=$cat_id";
            redirect(append_sid($redirect, true));
         }            

            // We must send out the $pic_id_array to store data between page changing
            $hidden_field = '';
            for ($i = 0; $i < count($pic_id_array); $i++)
            {
                $hidden_field .= '<input name="pic_id[]" type="hidden" value="'. $pic_id_array[$i] .'" />' . "\n";
            }

            //
            // Start output of page
            //

            $template->assign_vars(array(
                'MESSAGE_TITLE' => $user->lang['CONFIRM'],
                'MESSAGE_TEXT' => $user->lang['Album_delete_confirm'],
                'S_HIDDEN_FIELDS' => $hidden_field,
                'L_NO' => $user->lang['NO'],
                'YES_VALUE' => $user->lang['YES'],
                'S_CONFIRM_ACTION' => append_sid("album_modcp.$phpEx?mode=delete&amp;cat_id=$cat_id"),
                )
            );

            //
            // Generate the page
            //
            page_header($user->lang['Photo_Album']);

            $template->set_filenames(array(
                'body' => 'confirm_body.html')
            );

            page_footer();
        }
        else
        {
            //
            // Do the delete here...
            //
            if( isset($_POST['pic_id']) )
            {
                $pic_id = request_var('pic_id', array(0));
                if( is_array($pic_id) )
                {
                    $pic_id_sql = implode(',', $pic_id);
                }
                else
                {
                    trigger_error('Invalid request', E_USER_ERROR);
                }
            }
            else
            {
                trigger_error('No pics specified', E_USER_ERROR);
            }

            // well, we got the array of pic_id but we must do a check to make sure all these
            // pics are in this category (prevent some naughty moderators to access un-authorised pics)
            $sql = "SELECT COUNT(*) AS pic_count
                    FROM ". ALBUM_TABLE ."
                    WHERE pic_id IN ($pic_id_sql) AND pic_cat_id <> $cat_id";
            $result = $db->sql_query($sql);

            $row = $db->sql_fetchrow($result);

            if( $row['pic_count'] > 0 )
            {
                trigger_error($user->lang['Not_Authorised'], E_USER_WARNING);
            }

            // Delete all comments
            $sql = "DELETE FROM ". ALBUM_COMMENT_TABLE ."
                    WHERE comment_pic_id IN ($pic_id_sql)";
            $result = $db->sql_query($sql);

            // Delete all ratings
            $sql = "DELETE FROM ". ALBUM_RATE_TABLE ."
                    WHERE rate_pic_id IN ($pic_id_sql)";
            $result = $db->sql_query($sql);

            // Delete Physical Files
            // first we need filenames
            $sql = "SELECT pic_filename, pic_thumbnail
                    FROM ". ALBUM_TABLE ."
                    WHERE pic_id IN ($pic_id_sql)";
            $result = $db->sql_query($sql);

            $filerow = array();
            while( $row = $db->sql_fetchrow($result) )
            {
                $filerow[] = $row;
            }
            for ($i = 0; $i < count($filerow); $i++)
            {
                if( ($filerow[$i]['pic_thumbnail'] != '') and (@file_exists(ALBUM_CACHE_PATH . $filerow[$i]['pic_thumbnail'])) )
                {
                    @unlink(ALBUM_CACHE_PATH . $filerow[$i]['pic_thumbnail']);
                }
                @unlink(ALBUM_UPLOAD_PATH . $filerow[$i]['pic_filename']);
            }

            // Delete DB entry
            $sql = "DELETE FROM ". ALBUM_TABLE ."
                    WHERE pic_id IN ($pic_id_sql)";
            $result = $db->sql_query($sql);

            $message = $user->lang['Pics_deleted_successfully'] .'<br /><br />'. sprintf($user->lang['Click_return_category'], "<a href=\"" . append_sid("album_cat.$phpEx?cat_id=$cat_id") . "\">", "</a>") .'<br /><br />'. sprintf($user->lang['Click_return_modcp'], "<a href=\"" . append_sid("album_modcp.$phpEx?cat_id=$cat_id") . "\">", "</a>") . "<br /><br />" . sprintf($user->lang['Click_return_album_index'], "<a href=\"" . append_sid("album.$phpEx") . "\">", "</a>");

            trigger_error($message, E_USER_NOTICE);
        }
    }
    else
    {
        trigger_error('Invalid_mode', E_USER_ERROR);
    }
}


// +------------------------------------------------------+
// |  Powered by Photo Album 2.x.x (c) 2002-2003 Smartor  |
// +------------------------------------------------------+


?>
