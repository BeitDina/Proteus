<?php
/** 
*
* @package acp
* @version $Id: acp_album.php,v 1.0.0 2009/03/04 13:51:00 nuffmon Exp $
* @copyright (c) 2005 phpBB Group 
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* @package module_install
*/
class acp_album_info
{
  function module()
  {
    return array(
      'filename'  => 'acp_album',
      'title'    => 'ACP_CAT_ALBUM',
      'version'  => '1.0.0',
      'modes'    => array(
        'config'    => array('title' => 'ACP_ALBUM_CONFIG', 'auth' => 'acl_a_phpinfo', 'cat' => array('ACP_CAT_ALBUM')),
        'cache'    => array('title' => 'ACP_ALBUM_CLEARCACHE', 'auth' => 'acl_a_phpinfo', 'cat' => array('ACP_CAT_ALBUM')),
        'personal'    => array('title' => 'ACP_ALBUM_PERSONAL', 'auth' => 'acl_a_phpinfo', 'cat' => array('ACP_CAT_ALBUM')),
        'cats'    => array('title' => 'ACP_ALBUM_CATS', 'auth' => 'acl_a_phpinfo', 'cat' => array('ACP_CAT_ALBUM')),
        'auth'    => array('title' => 'ACP_ALBUM_AUTH', 'auth' => 'acl_a_phpinfo', 'cat' => array('ACP_CAT_ALBUM')),		
      ),
    );
  }

  function install()
  {
  }

  function uninstall()
  {
  }
}

?>
